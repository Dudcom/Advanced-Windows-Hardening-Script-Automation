#!/bin/bash
ansible-lint -p playbooks/*/main.yml
