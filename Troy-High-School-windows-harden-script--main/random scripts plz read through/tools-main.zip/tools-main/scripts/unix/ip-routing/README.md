Jake's lovely ip routing scripts.

`route-load.sh`: loads an ip route config
`route-save.sh`: saves the current ip route config to a file (somewhere in /tmp by default)
`auto-route-save.sh`: automatically saves ip route configs upon detecting changes. To keep this running in the background, use either `nohup` or `disown`.
`filewall-info.sh`: checks if there are any active firewalls on the system

