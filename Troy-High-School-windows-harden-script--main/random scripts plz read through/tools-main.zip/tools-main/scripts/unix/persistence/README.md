Persistence things and whatnot.

# Rootkits
For linux kernels 2.6.x thru 6.x use diamorphine. For linux kernels 6.x you can also use j-rootkit.

# Backdoors
- `tunnelbees` - ssh honeypot, correct ssh port obscured. relies on pre-shared key.
- `icmp-backdoor` - simple icmp backdoor, integrated into `j-rootkit` but also works standing alone
