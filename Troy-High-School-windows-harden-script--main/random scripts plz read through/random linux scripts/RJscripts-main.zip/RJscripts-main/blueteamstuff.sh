apt install git -y
git clone "https://github.com/UCI-CCDC/CCDC"
wget "https://github.com/UCI-CCDC/CCDC/archive/refs/tags/v3.1.zip"
