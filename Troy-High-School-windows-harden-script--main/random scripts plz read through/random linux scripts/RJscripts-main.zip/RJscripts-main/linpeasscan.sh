wget https://github.com/carlospolop/PEASS-ng/releases/download/20230108/linpeas.sh
chmod +x linpeas.sh
echo "RUNNING LINPEAS..."
./linpeas.sh > ~/linpeas.txt
