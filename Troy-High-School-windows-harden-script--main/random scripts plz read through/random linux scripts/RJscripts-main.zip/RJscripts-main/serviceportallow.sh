sudo ufw enable
sudo ufw logging high
sudo ufw logging on
sudo ufw allow 2049
sudo ufw allow 111
sudo ufw allow 110
sudo ufw allow 993
sudo ufw allow 995
sudo ufw allow 143
sudo ufw allow 25
sudo ufw allow 22

sudo ufw allow 2049/tcp
sudo ufw allow 111/tcp
sudo ufw allow 110/tcp
sudo ufw allow 993/tcp
sudo ufw allow 995/tcp
sudo ufw allow 143/tcp
sudo ufw allow 25/tcp
sudo ufw allow 22/tcp

sudo ufw allow 2049/udp
sudo ufw allow 111/udp
sudo ufw allow 110/udp
sudo ufw allow 993/udp
sudo ufw allow 995/udp
sudo ufw allow 143/udp
sudo ufw allow 25/udp
sudo ufw allow 22/udp
