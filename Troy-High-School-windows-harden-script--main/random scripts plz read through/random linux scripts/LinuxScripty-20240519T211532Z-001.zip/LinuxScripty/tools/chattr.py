#!/bin/python3
import fcntl
from array import array

# https://elixir.bootlin.com/linux/v6.7/source/include/uapi/linux/fs.h
"""
#define FS_IMMUTABLE_FL			0x00000010 /* Immutable file */
#define FS_APPEND_FL			0x00000020 /* writes to file may only append */
...
#define	FS_IOC_GETFLAGS			_IOR('f', 1, long)
#define	FS_IOC_SETFLAGS			_IOW('f', 2, long)
"""
FS_IMMUTABLE_FL = 0x00000010
FS_APPEND_FL = 0x00000020
FS_IOC_GETFLAGS = 0x80086601
FS_IOC_SETFLAGS = 0x40086602

def mark_mutable(f_name):
    try:
        with open(f_name, 'r') as f: 
            arg = array('L', [0])
            fcntl.ioctl(f, FS_IOC_GETFLAGS, arg, True)
            arg[0] = arg[0] & ~FS_IMMUTABLE_FL
            arg[0] = arg[0] & ~FS_APPEND_FL
            fcntl.ioctl(f.fileno(), FS_IOC_SETFLAGS, arg, True)
        return True
    except Exception as e:
        print(f'Failed to mark mutable {f_name}: {e}')
        return False

if __name__ == '__main__':
    from sys import argv
    from os.path import isdir, abspath
    pth = abspath(argv[1])
    if isdir(pth):
        from pathlib import Path
        for x in Path(pth).rglob('*'):
            if not isdir(x):
                mark_mutable(x)
    else:
        mark_mutable(pth)

