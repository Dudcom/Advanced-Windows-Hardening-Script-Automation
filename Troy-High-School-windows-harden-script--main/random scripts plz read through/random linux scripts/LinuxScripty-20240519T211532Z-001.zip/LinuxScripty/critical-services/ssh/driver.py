from os.path import abspath, dirname, join
import sys
from config import *
CURRENT_DIR = dirname(abspath(__file__))
CONFIG_DIR = join(CURRENT_DIR, 'configs')
CRIT_SERVICE_DIR = abspath(dirname(CURRENT_DIR))
ROOT_DIR = abspath(dirname(CRIT_SERVICE_DIR))
sys.path.append(ROOT_DIR)
# fmt: off
from utils import *
# fmt: on

CONFIG = r"""
AcceptEnv LANG LC_*
AddressFamily inet
AllowAgentForwarding no
AllowGroups sshusers
AllowStreamLocalForwarding no
AllowTcpForwarding no
AllowUsers {users}
AuthenticationMethods {auth_methods}
# CA Configs 
AuthorizedKeysFile .ssh/authorized_keys
CASignatureAlgorithms ssh-ed25519,ecdsa-sha2-nistp256, ecdsa-sha2-nistp384,ecdsa-sha2-nistp521, sk-ssh-ed25519@openssh.com, sk-ecdsa-sha2-nistp256@openssh.com, rsa-sha2-512, rsa-sha2-256
Banner /etc/donothackpls
ChannelTimeout *=1m
Ciphers aes256-gcm@openssh.com
ClientAliveCountMax 1
ClientAliveInterval 1
Compression no
DisableForwarding yes
ExposeAuthInfo no
FingerprintHash sha256
GatewayPorts no
KexAlgorithms curve25519-sha256@libssh.org
LoginGraceTime 5
LogLevel VERBOSE
MACs hmac-sha2-512-etm@openssh.com
GSSAPICleanupCredentials yes
GSSAPIStrictAcceptorCheck yes
HostbasedAcceptedAlgorithms rsa-sha2-512-cert-v01@openssh.com, ssh-ed25519-cert-v01@openssh.com, ecdsa-sha2-nistp521-cert-v01@openssh.com
HostKeyAlgorithms rsa-sha2-512-cert-v01@openssh.com, ssh-ed25519-cert-v01@openssh.com, ecdsa-sha2-nistp521-cert-v01@openssh.com
IgnoreRhosts yes
IgnoreUserKnownHosts yes
KerberosGetAFSToken yes
KerberosOrLocalPasswd no
KerberosTicketCleanup yes
MaxAuthTries 1
MaxSessions 1
MaxStartups 5:100:6
ModuliFile /etc/moduli
PermitEmptyPasswords no
PermitListen localhost:{port}
Port {port}
PermitOpen none
PermitRootLogin no
PermitTTY no
PermitTunnel no
PermitUserEnvironment no
PermitUserRC no
PerSourceMaxStartups 1
PrintLastLog no
PrintMotd no
PubkeyAcceptedAlgorithms ssh-ed25519-cert-v01@openssh.com
PubkeyAuthOptions touch-required, verify-required
RekeyLimit 10M
RequiredRSASize 2048
RDomain none
StreamLocalBindMask 0177
StreamLocalBindUnlink yes
StrictModes yes
SyslogFacility AUTH
TCPKeepAlive yes
UnusedConnectionTimeout 1m
UseDNS no
UsePAM no
X11Forwarding no
X11DisplayOffset 0
X11UseLocalhost no
"""
MAPPING = {
    "ssh": "/etc/pam.d/sshd"
}
SSH_CS_CONFIG = r"""
AuthorizedPrincipalsFile /etc/ssh/principals/%u
TrustedUserCAKeys /etc/ssh/ca_keys
"""
if SSH_CS:
    CONFIG += SSH_CS_CONFIG

passwd_text = open("/etc/passwd").read()
users = []
for line in passwd_text.split("\n"):
    uid = int(line.split(":")[2])
    if uid >= 1000 and uid <= 65534:
        users.append(line.split(":")[0])
users = ",".join(users)
CONFIG = CONFIG.format(users=users, auth_methods=",".join(SSH_ALLOWED_AUTHENTICATION_METHODS), port=PORT)
for method in ["gssapi-with-mic", "hostbased", "keyboard-interactive", "password", "publickey"]:
    allowed = "no"
    if method in SSH_ALLOWED_AUTHENTICATION_METHODS:
        allowed = "yes"
    
    match method:
        case "publickey":
            CONFIG += f"PubkeyAuthentication {allowed}\n"
        case "gssapi-with-mic":
            CONFIG += f"GSSAPIAuthentication {allowed}\n"
        case "hostbased":
            CONFIG += f"HostbasedAuthentication {allowed}\n"
        case "keyboard-interactive":
            CONFIG += f"KbdInteractiveAuthentication {allowed}\n"
        case "password":
            CONFIG += f"PasswordAuthentication {allowed}\n"
        case _:
            raise Exception("Unknown authentication method")

def configure_ssh():
    """
    @notice    Configures SSH
    @return    None
    """
    write("/etc/ssh/sshd_config", CONFIG)
    for k,v in MAPPING.items():
        copyfile(join(CONFIG_DIR, k), v)
    return None