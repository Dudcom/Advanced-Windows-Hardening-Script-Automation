from os.path import abspath, dirname, join
import sys
CURRENT_DIR = dirname(abspath(__file__))
CONFIG_DIR = join(CURRENT_DIR, 'configs')
CRIT_SERVICE_DIR = abspath(dirname(CURRENT_DIR))
ROOT_DIR = abspath(dirname(CRIT_SERVICE_DIR))
sys.path.append(ROOT_DIR)
# fmt: off
from utils import *
# fmt: on


users = open('/etc/passwd').read().splitlines()
users = [x.split(':')[0] for x in users if int(x.split(':')[2]) >= 1000] + ['root']
if 'nobody' in users:
    users.remove('nobody')
run_command_unhandled("apt-get install samba-common-bin -y")
write("/var/lib/samba/private/passdb.tdb", "")
for user in users:
    run_command_unhandled(f"smbpasswd -a {user}", input_data="password\npassword\n")