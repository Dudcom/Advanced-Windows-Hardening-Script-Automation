# fmt: off
from os.path import abspath
from sys import path
path.append(abspath(__file__ + '../../'))
from utils import *
from pathlib import Path
# fmt: on
mimes_ign = ["/var/snap", "/var/lib", "/usr/src", "/usr/lib", "/usr/share/locale", "/usr/share/icons", "/boot", "/dev"]

# Given the files /baselines/files/dynamic/files_after.out and the files on file sys, mime type sort them


def create_file_tree():
    """Find files created, then sort them by mimetype and mime subtype"""
    log('Creating file mime tree', 'files', priority='INFO')
    files = get_created_files()
    if not files:
        return False
    mime_types = guess_mime_types(files)
    if not exists('/baselines/mimes'):
        create_dir('/baselines/mimes')
    for file in files:
        mime_type = mime_types[file]
        if file[0] == '/':
            file = file[1:]
        fname = file.replace("/", "_")
        if fname[-1] == '_':
            fname = fname[:-1]
        pth = join('/baselines/mimes', mime_type)
        if not exists(pth):
            create_dir(pth)
        if not exists(join(pth, fname)):
            symlink("/" + file, join(pth, fname))
    return True


def guess_mime_types(files):
    """Given a list of files, return a dict of {file: mime_type}"""
    types = {}
    for file in files:
        types[file] = fetch_mime_type(file)
    return types


def get_created_files():
    """Gets all files not accounted for by dynamic baseline"""
    files = set(open('/baselines/files.out').read().splitlines())
    #files = [x for x in files if not all(y in x for y in mimes_ign)]
    for x in mimes_ign:
        ignore = set([*Path(x).rglob('*'),])
        ignore = {str(y) for y in ignore}
        files = files.difference(ignore)
    files = list(files)
    return files


def fetch_mime_type(path):
    """Fetch the mime type of a file"""
    path = process_path(path)
    out = run_command_unhandled(f'file --mime-type {path}')[0].strip()
    if ':' not in out:
        return 'unknown'
    return out.split(': ')[1]
