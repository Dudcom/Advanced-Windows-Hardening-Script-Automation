# fmt: off
from os.path import abspath, getsize
from sys import path
path.append(abspath(__file__ + '../../'))
from utils import *
from os import chdir
from typing import *
from enum import Enum
import tempfile
from os.path import dirname, abspath
import tarfile
# fmt: on

def setup_package_baselines():
    new_packages = get_installed_packages()
    all_packages = get_all_packages()
    if not exists('/baselines/packages'):
        create_dir('/baselines/packages')
    open('/baselines/packages/all_packages', 'w').write('\n'.join(all_packages))
    open('/baselines/packages/new_packages', 'w').write('\n'.join(new_packages))
    return True
