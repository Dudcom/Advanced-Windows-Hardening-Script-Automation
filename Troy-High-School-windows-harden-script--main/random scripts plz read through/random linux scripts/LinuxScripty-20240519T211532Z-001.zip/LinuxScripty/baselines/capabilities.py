# fmt: off
from os.path import abspath
from sys import path
path.append(abspath(__file__ + '../../'))
from utils import *
# fmt: on

# Baselining the output of getcap -R /

def setup_capability_baseline():
    caps = run_command_unhandled(
        'getcap -r / 2>/dev/null')[0].strip().splitlines()
    if '' in caps:
        caps.remove('')
    caps = [x for x in caps if not x.startswith('/baselines')]
    write('/baselines/capabilities', '\n'.join(caps))
    return True
