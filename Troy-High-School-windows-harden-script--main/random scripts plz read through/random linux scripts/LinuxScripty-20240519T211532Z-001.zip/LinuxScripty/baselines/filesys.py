# fmt: off
from os.path import abspath, getsize
from sys import path
path.append(abspath(__file__ + '../../'))
from utils import *
from os import chdir
from typing import *
from enum import Enum
import tempfile
from os.path import dirname, abspath
# fmt: on
# symlinks
symlinks_file = open(f"{baselines_dir}/symlinks").read().splitlines()
# symlink -> source
symlinks = {}
for line in symlinks_file:
    if '->' in line:
        spl = line.split('->')
        symlinks[spl[0].lstrip('/')] = spl[1].lstrip('/')

def get_pkg_info(pkgs: List[str] | str) -> Dict[str, str | Dict[str, str]]:
    """
    @param pkgs A list or a package name
    @return The acls, hashes, and files associated with a package (or packages)
    """
    if type(pkgs) == str:
        pkgs = [pkgs]
    packages = {'hashes': {}, 'acls': '', 'files': {}, 'dependencies': {}, 'attrs': ''}
    for pkg in pkgs:
        cwd = getcwd()
        try:
            log(f"Getting info for {pkg}", 'packages')
            with tempfile.TemporaryDirectory() as tmpdir:
                chdir(tmpdir)
                run_command('apt download ' + pkg)
                new = listdir(tmpdir)
                if not new:
                    log(f"Failed to download {pkg}", 'packages', 'WARN')
                for deb in new:
                    data = extract_package_data(deb)
                    hashes,acls,files,deps,attrs = data['hashes'],data['acls'],data['files'],data['dependencies'],data['attrs']
                    files = [join('/', x) for x in files]
                    packages['hashes'].update(hashes)
                    packages['acls'] += acls.strip() + '\n'
                    packages['attrs'] += attrs.strip() + '\n'
                    # lookup table construction
                    for file in files:
                        if file not in packages['files']:
                            packages['files'][file] = pkg
                    packages['dependencies'][pkg] = deps
                    if exists(deb):
                        remove(deb) # cleanup
                chdir(cwd)
        except KeyboardInterrupt:
            log(f"Skipping {pkg} (kybd inter)", 'packages', 'WARN')
            chdir(cwd)
    packages['acls'] = packages['acls'].strip() + '\n\n'
    packages['attrs'] = packages['attrs'].strip()
    return packages



def find_top_level(deps: Dict[str, List[str]]) -> Dict[str, str | Dict]: # type rather complicated
    # find top level packages
    top_level = []
    for pkg in deps:
        for other in deps:
            if pkg in deps[other]:
                break
        else:
            top_level.append(pkg)
    return top_level



return_codes = Enum('return_codes', ['OK', 'FAIL', 'NOT_FOUND', 'IS_LINK', 'IS_DIR', 'CREATED'])
def check_file(file: str, hash: Dict[str, str]) -> return_codes:
    """
    @notice Check if a file matches a hash
    @param file The file name
    @param hash The hash information, which will have size, sha256, md5.
    @return The status of the file
    """
    if not exists(file):
        return return_codes.NOT_FOUND
    if islink(file):
        return return_codes.IS_LINK
    if isdir(file):
        return return_codes.IS_DIR
    if getsize(file) != hash['size']:
        return return_codes.FAIL
    sha256_hash = hash['sha256']
    file_sha256 = hshfile(file)
    if file_sha256 != sha256_hash:
        return return_codes.FAIL
    ## sha256 collisions is like not something we have to worry about...
    return return_codes.OK

def check_files(hashes: Dict[str, Dict[str, str]]) -> Dict[str, return_codes]:
    """
    @notice Check a list of files against a dict of hashes
    @param hashes A dictionary mapping files to their hash dicts
    @return The status codes of all it's files
    """
    files = list(hashes.keys())
    ret = {}
    for file in files:
        ret[file] = check_file(file, hashes[file])
    return ret

@requires(files=[f'{baselines_dir}/deep'])
def find_mismatch():
    """
    @notice Find mismatches on system
    @return Any mismatches on the system and the lookup table for files
    """
    installed = get_installed_packages()
    log("Got installed packages", 'fsys')
    packages = get_pkg_info(installed)
    log("Got package info", 'fsys')
    #tree = packages['tree']
    #open('/baselines/tree.out', 'a').write(str(tree))
    acls = packages['acls']
    open('/baselines/acls.out', 'a').write(acls)
    attrs = packages['attrs']
    open('/baselines/attrs.out', 'a').write(attrs)
    hashes = packages['hashes']
    # reverse lookup table
    files = packages['files']
    if not exists('/baselines/packages'):
        create_dir('/baselines/packages')
    top_level = find_top_level(packages['dependencies'])
    open('/baselines/packages/top_level', 'w').write('\n'.join(top_level))
    log("Got top level packages", 'fsys', "PRIOR")
    base = hashdeep_from_file(f'{baselines_dir}/deep')
    hashes.update(base)
    log("hashes computed", 'fsys')
    # check files
    log('Checking file hashes', 'files')
    codes = check_files(hashes)
    log('Done checking file hashes', 'files')
    expected_files = list(files.keys()) + files_from_hashdeep(f'{baselines_dir}/deep')
    expected_files = list(set(expected_files))
    on_sys = listdir_recursive('/', exclude_dirs=tool_root_directories + exclude_dirs)
    on_sys = [join('/', x) for x in on_sys]
    on_sys = list(set(on_sys))
    ## optimizing cuz hash lookups
    on_sys = set(on_sys)
    # removing our baselines
    on_sys = {x for x in on_sys if not any(x.startswith(y) for y in ['/baselines', '/media', '/mnt'])}
    expected_files = set(expected_files)
    log("Checking for unexpected files", 'files')
    diff = on_sys.difference(expected_files)
    open('/baselines/files.out', 'w').write('\n'.join(diff))
    unexpected = {x: return_codes.CREATED for x in diff}
    log("Done checking for unexpected files", 'files')
    codes.update(unexpected)
    codes = {x:codes[x] for x in codes if codes[x] not in [return_codes.OK, return_codes.IS_DIR, return_codes.IS_LINK]}
    return codes, files


def construct_baselines(tarfile_pth: str, codes: Dict[str, return_codes], files: Dict[str,str]):
    """
    @param tarfile_pth The directory of the usb that stores the baselined fs, likely in /media
    @param codes The mapping of files to codes
    @param files The mapping of files to packages, so we can invoke extract_files_from
    @return A boolean indicating the status of the operation
    """
    baselinedir = "/baselines/fs/dynamic"
    systemdir = "/baselines/fs/system"
    create_dir(baselinedir)
    create_dir(systemdir)
    # cases we have to cover: FAIL (modified), NOT_FOUND (exists in baseline), CREATED (does not exist in baseline and cannot be accounted for dynamically)
    pkg_to_file = {}
    log("Using file extraction", "fsys")
    for file in codes:
        try:
            if '->' in file:
                continue # skip symlinks
            if file[0] != '/':
                file = '/' + file
            if any(file.startswith(x) for x in tool_root_directories + exclude_dirs + ['/dev', '/boot']) or file.startswith(abspath(__file__ + '/../../')) or file.startswith(tarfile_pth):
                continue
            code = codes[file]
            match code:            
                case return_codes.NOT_FOUND:
                    target_file = join(baselinedir, file[1:])
                    target_dir = abspath(dirname(target_file))
                    create_dir(target_dir)
                    extract_file(tarfile_pth, file[1:], target_file)
                case return_codes.CREATED:
                    target_file = join(systemdir, file[1:])
                    target_dir = abspath(dirname(target_file))
                    create_dir(target_dir)
                    symlink(file, target_file)
                case return_codes.FAIL:
                    if file in files:
                        pkg = files[file]
                        if pkg not in pkg_to_file:
                            pkg_to_file[pkg] = []
                        pkg_to_file[pkg].append(file)
                        target_file = join(systemdir, file[1:])
                        target_dir = abspath(dirname(target_file))
                        create_dir(target_dir)
                        symlink(file, target_file)
                    else:
                        target_file = join(baselinedir, file[1:])
                        target_dir = abspath(dirname(target_file))
                        create_dir(target_dir)
                        extract_file(tarfile_pth, file[1:], target_file)
                        target_file = join(systemdir, file[1:])
                        target_dir = abspath(dirname(target_file))
                        create_dir(target_dir)
                        symlink(file, target_file)

        except Exception as e:
            log(f'Failed to baseline {file} (code: {codes[file]}): {e}', 'files', 'WARN')
    log("Using package extraction", "fsys")
    for pkg in pkg_to_file:
        extracting = pkg_to_file[pkg]
        extract_files_from(pkg, extracting, baselinedir)
    
    # symlinks
    symlinks_file = open(f"{baselines_dir}/symlinks")
    # symlink -> source
    symlinks = {x.split('->')[0].lstrip('/'):x.split('->')[1].lstrip('/') for x in symlinks_file.read().splitlines()}
    symlinks_file.close()
    for link in symlinks:
        source = join(baselinedir, symlinks[link])
        target = join(baselinedir, link)
        try:
            symlink(source, target)
        except Exception as e:
            from os import symlink as syml
            try:
                syml(source, target)
            except Exception as e:
                if exists(source) and not any(x in source for x in ['/usr', '/boot']):
                    log(f"Failed to symlink {source} to {target}: {e}", 'files', 'WARN')
    symlink(tarfile_pth, '/baselines/fs/default')
    return True





def extract_file(tarfile_pth: str, file: str, target_file: str):
    # extract file from tarfile, write it to it to target_file
    #with tarfile.open(tarfile_pth, "r:gz") as tar:
    #    buffer = tar.extractfile(file)
    #    with open(target_file, 'wb') as f:
    #        f.write(buffer.read())
    #return True
    # DIRECTORY rewrite: param set becomes (directory path, file, target_file)
    copyfile(join(join(tarfile_pth, 'fs'), file), target_file)
    return True


def rslv_symlink(pth, depth=10):
    c = 0
    while pth in symlinks:
        if c > depth:
            break
        c += 1
        pth = symlinks[pth]
    return pth

@requires(files=[f'{baselines_dir}/homedir'])
def setup_home_baselines():
    users = [x.split(":")[0] for x in open('/etc/passwd').read().splitlines()]
    for user in users:
        # baselinedir = "/baselines/fs/dynamic"
        symlink(f'{baselines_dir}/homedir', f'/baselines/fs/dynamic/home/{user}')
    return True

@requires(files=[f'{baselines_dir}/kmods'])
def setup_kmods():
    default_kmods = open(f'{baselines_dir}/kmods').read().splitlines()
    stdout, stderr, _ = run_command('lsmod')
    on_sys = [x.split(" ")[0] for x in stdout.split('\n')[1:]]
    new = [x for x in on_sys if x not in default_kmods]
    write('/baselines/new_kmods', '\n'.join(new))
    return True

@requires(files=[f'{baselines_dir}/deep'])
def setup_file_baselines(tarfile_pth: str):
    """
    @param tarfile_pth: where the usb is
    """
    for link in symlinks:
        source = join(tarfile_pth, symlinks[link])
        target = join(tarfile_pth, link)
        try:
            symlink(source, target)
        except Exception as e:
            from os import symlink as syml
            try:
                syml(source, target)
            except Exception as e:
                # could be a symlink
                source = rslv_symlink(source)
                try:
                    symlink(source, target)
                except Exception as e:
                    if exists(source) and not any(x in source for x in ['/usr', '/boot']):
                        log(f"Failed to symlink {source} to {target}: {e}", 'files', 'WARN')
    log("completed symlink setup", 'files')
    codes, files = find_mismatch()
    log("completed mismatch finding", 'files')
    construct_baselines(tarfile_pth=tarfile_pth, codes=codes, files=files)
    setup_home_baselines()
    setup_kmods()
    return True