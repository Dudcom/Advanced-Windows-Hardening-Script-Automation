from os.path import islink, abspath, join, realpath
from pathlib import Path
# fmt: off
import sys
sys.path.append(abspath(__file__ + '/..'*2))
from utils import *
# fmt: on

@ensure_exists(CLIENT_OUT_DIR)
def setup_symlinks():
    f = open(join(CLIENT_OUT_DIR,'symlinks'), 'w')
    for x in listdir('/'):
        if x not in tool_root_directories + exclude_dirs + ['home']:
            for p in Path('/' + x).rglob('*'):
                if islink(p):
                    f.write(f'{p}->{realpath(p)}\n')
    return None
