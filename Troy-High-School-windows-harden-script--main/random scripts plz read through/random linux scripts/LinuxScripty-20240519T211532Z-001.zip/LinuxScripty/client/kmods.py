from os.path import abspath
# fmt: off
import sys
sys.path.append(abspath(__file__ + '/..'*2))
from utils import *
# fmt: on

@ensure_exists(CLIENT_OUT_DIR)
def setup_kmods():
    """
    @notice    Sets up kmods
    @return    None
    """
    stdout, stderr, code = run_command('lsmod')
    if stderr:
        log(f'Error getting kernel modules: {stderr}', 'kernel_modules')
        return None
    kmods = [x.split(" ")[0] for x in stdout.split('\n')[1:]]
    write(CLIENT_OUT_DIR + '/kmods', '\n'.join(kmods))
    return None