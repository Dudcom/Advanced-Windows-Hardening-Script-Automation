from os.path import abspath
# fmt: off
import sys
sys.path.append(abspath(__file__ + '/..'*2))
from utils import *
# fmt: on

@ensure_exists(CLIENT_OUT_DIR)
def setup_caps():
    """
    @notice    Sets up file acls for the tool
    @return    None
    """
    caps = run_command('getcap -r /')[0].strip().split('\n')
    write(CLIENT_OUT_DIR + '/capabilities', "\n".join(caps))
    return None