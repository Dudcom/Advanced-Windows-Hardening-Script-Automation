from os.path import abspath
# fmt: off
import sys
sys.path.append(abspath(__file__ + '/..'*2))
sys.path.append(abspath(__file__ + '/..'))
# fmt: on
from facls import *
from attrs import setup_attrs
from packages import *
from filesys import *
from deep import *
from caps import *
from syml import *
from utils import *
from kmods import *
from home import *
def main():
    """
    @notice    Sets up file acls for the tool
    @return    None
    """
    setup_acls()
    log('setup_acls done', 'client')
    setup_attrs()
    log('setup_attrs done', 'client')
    setup_packages()
    log('setup_packages done', 'client')
    setup_filesys()
    log('setup_filesys done', 'client')
    setup_deep()
    log('setup_deep done', 'client')
    setup_caps()
    log('setup_caps done', 'client')
    setup_symlinks()
    log('setup_symlinks done', 'client')
    setup_kmods()
    log('setup_kmods done', 'client')
    setup_home()
    log('setup_home done', 'client')
    return None


