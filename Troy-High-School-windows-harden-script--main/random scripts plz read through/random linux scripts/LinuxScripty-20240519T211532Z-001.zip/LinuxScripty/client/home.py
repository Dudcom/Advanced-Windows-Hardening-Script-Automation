from os.path import abspath
# fmt: off
import sys
sys.path.append(abspath(__file__ + '/..'*2))
from utils import *
# fmt: on

@ensure_exists(CLIENT_OUT_DIR)
def setup_home():
    """
    @notice    Sets up home dir
    @return    None
    """
    stdout, stderr, code = run_command('useradd -m test')
    if stderr and 'COST' not in stderr:
        log(f'Error creating home dir: {stderr}', 'home')
        return None
    copy('/home/test', CLIENT_OUT_DIR + '/homedir')
    return None