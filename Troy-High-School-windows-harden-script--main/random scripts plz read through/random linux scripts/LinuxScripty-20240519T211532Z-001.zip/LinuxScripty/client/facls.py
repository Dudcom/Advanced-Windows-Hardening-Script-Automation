from os import getcwd
from os.path import abspath
# fmt: off
import sys
sys.path.append(abspath(__file__ + '/..'*2))
from utils import *
# fmt: on

@ensure_exists(CLIENT_OUT_DIR)
def setup_acls():
    """
    @notice    Sets up file acls for the tool
    @return    None
    """
    facls = ""
    for x in listdir('/'):
        if x not in tool_root_directories + ['sbin', 'bin', 'lib', 'sys', 'proc', 'snap', 'run', 'rofs', 'lib64', 'lib32']:
            log(f'Getting ACLs for /{x}', 'facls')
            acls = getfacl_dir(f'/{x}', normalize_output=True)
            facls += acls + '\n\n'
    write(CLIENT_OUT_DIR + '/acls', facls)
    return None
