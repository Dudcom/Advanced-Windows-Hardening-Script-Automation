from os.path import abspath
# fmt: off
import sys
sys.path.append(abspath(__file__ + '/..'*2))
from utils import *
# fmt: on

@ensure_exists(CLIENT_OUT_DIR)
def setup_deep():
    """
    @notice    Sets up file acls for the tool
    @return    None
    """
    deep = ""
    for x in listdir('/'):
        if x not in tool_root_directories + exclude_dirs + ['home', 'var', 'dev', 'boot']:
            deep += create_hashdeep('/' + x).strip() + '\n'
        if x == 'var':
            for y in listdir('/var'):
                if y not in ['run']:
                    deep += create_hashdeep('/var/' + y).strip() + '\n'
    write(CLIENT_OUT_DIR + '/deep', deep)
    return None