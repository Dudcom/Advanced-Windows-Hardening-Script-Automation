from os.path import abspath
# fmt: off
import sys
sys.path.append(abspath(__file__ + '/..'*2))
from utils import *
# fmt: on

@ensure_exists(CLIENT_OUT_DIR)
def setup_attrs():
    """
    @notice    Sets up file acls for the tool
    @return    None
    """
    attrs = ""
    for x in listdir('/'):
        if x not in tool_root_directories + exclude_dirs + ['home', 'var', 'dev', 'boot']:
            log(f'Getting attrs for /{x}', 'attrs')
            attr = lsattr_dir(f'/{x}', normalize_output=True).strip()
            attrs += attr + '\n'
        if x == 'var':
            for y in listdir('/var'):
                if y not in ['run']:
                    log(f'Getting attrs for /var/{y}', 'attrs')
                    attr = lsattr_dir(f'/var/{y}', normalize_output=True).strip()
                    attrs += attr + '\n'
    attrs = attrs.replace('\n\n', '\n').strip()
    attrs = "\n".join([x for x in attrs.split('\n') if x != ''])
    write(CLIENT_OUT_DIR + '/attrs', attrs)
    return None