from os.path import abspath
# fmt: off
import sys
sys.path.append(abspath(__file__ + '/..'*2))
from utils import *
# fmt: on

@ensure_exists(CLIENT_OUT_DIR)
def setup_packages():
    """
    @notice    Sets up file acls for the tool
    @return    None
    """
    packages = get_all_packages()
    write(CLIENT_OUT_DIR + '/packages', "\n".join(packages))
    return None