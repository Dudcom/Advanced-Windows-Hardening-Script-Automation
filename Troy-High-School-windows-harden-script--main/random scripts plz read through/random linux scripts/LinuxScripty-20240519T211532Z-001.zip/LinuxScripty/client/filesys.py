from os.path import abspath
import tarfile
# fmt: off
import sys
sys.path.append(abspath(__file__ + '/..'*2))
from utils import *
# fmt: on

@ensure_exists(CLIENT_OUT_DIR + '/fs')
def setup_filesys():
    """
    @notice    Sets up file acls for the tool
    @return    None
    """
    for x in listdir('/'):
        if x not in tool_root_directories + exclude_dirs + ['home', 'var', 'dev', 'boot']:
            log(f'Copying {x}', 'fs')
            copy('/' + x, CLIENT_OUT_DIR + '/fs/' + x)
        if x == 'var':
            for y in listdir('/var'):
                if y not in ['run']:
                    log(f'Copying /var/{y}', 'fs')
                    copy('/var/' + y, CLIENT_OUT_DIR + '/fs/var/' + y)
    return None