from utils import *
from sys import argv
usb_dir = argv[1]
if 'fs' in listdir(usb_dir):
    for x in listdir(usb_dir):
        if x != 'fs':
            copy(join(usb_dir, x), join(baselines_dir, x))
    usb_dir = join(usb_dir, 'fs')

from __init__ import do_cyberpatriot
do_cyberpatriot(usb_dir=usb_dir)
