import subprocess
from typing import Tuple

def run_command(command: str, input_data: str=None) -> Tuple[str, str, int]:
    """Run a command and return stdout, stderr, and return code"""
    try:
        process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=True,
            text=True,
        )
        if input_data:
            stdout, stderr = process.communicate(input=input_data)
        else:
            stdout, stderr = process.communicate()
        return_code = process.returncode
        return stdout, stderr, return_code
    except Exception as e:
        return None, str(e), -1


def run_command_unhandled(command: str, input_data: str=None) -> Tuple[str, str, int]:
    """Run a command and return stdout, stderr, and return code, but raise an exception if stderr is not empty (useful when we do not handle stderr)"""
    stdout, stderr, return_code = run_command(command, input_data)
    if stderr:
        raise Exception(f"Error running command: {stderr}")
    return stdout, stderr, return_code

