import shlex
from shlex import quote
import re
from typing import *
from .hashes import *
from .cmd import *
from .file_wrappers import *
from .acls import *
from .packages import *
# Directory of utils folder
utils_dir = abspath(__file__ + '/..')

# Directory of tooling folder
tooling_dir = abspath(utils_dir + '/..')


def setkey(config: str, regex_from: str, to: str) -> bool:
    """Set a key in a config file"""
    # config = process_path(config)
    # regex_from = process_path(regex_from)
    # to = process_path(to)
    backup(config)
    data = open(config).read()
    new_data = re.sub(regex_from, to, data)
    write(config, new_data)
    return True



def process_path(path: str) -> str:
    """Process a path to be safe for shell"""
    pth = shlex.quote(abspath(path))
    if f"{tooling_dir}/'" in pth:
        pth = pth.replace(f"{tooling_dir}/'", "'")
    return pth


def kill_service(service: str) -> bool:
    """Kill a service"""
    do = ['stop', 'disable', 'mask']
    for item in do:
        run_command_unhandled(f'systemctl {item} {service} 2>/dev/null')
    return True


def start_service(service: str) -> bool:
    """Start a service"""
    do = ['unmask', 'enable', 'start']
    for item in do:
        run_command_unhandled(f'systemctl {item} {service} 2>/dev/null')
    return True

def restart_service(service: str) -> bool:
    """Restart a service"""
    kill_service(service)
    start_service(service)
    return True

def requires(files: List[str]=[], packages: List[str]=[]) -> Callable:
    """Run a function, error if files aren't found, install packages if not found"""
    def decorator(func: Callable) -> Callable: # returnable decorator, to actually decorate the function
        def wrapper(*args, **kwargs) -> Any: # wrapper to be returned by the decoratore that blankets it with cheks
            install(packages)
            for file in files:
                if not exists(file):
                    raise Exception(f"File {file} not found") # raise to ensure we don't continue
            return func(*args, **kwargs)
        return wrapper
    return decorator

def ensure_exists(*directories) -> Callable:
    """Run a function, create any directories in directories if they don't exist"""
    def decorator(func: Callable) -> Callable: # returnable decorator, to actually decorate the function
        def wrapper(*args, **kwargs) -> Any: # wrapper to be returned by the decoratore that blankets it with cheks
            for directory in directories:
                if not exists(directory):
                    create_dir(directory)
            return func(*args, **kwargs)
        return wrapper
    return decorator
