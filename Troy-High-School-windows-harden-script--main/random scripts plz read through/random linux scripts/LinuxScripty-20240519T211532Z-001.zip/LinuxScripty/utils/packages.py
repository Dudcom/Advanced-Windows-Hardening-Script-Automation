from .hashes import *
from .cmd import run_command_unhandled
from .file_wrappers import *
from .acls import *
from os import getcwd
import string

def ls_to_octal(line: str) -> str:
    # ----------  -> octal
    is_dir = line[0]
    if is_dir == 'l':
        return 'symlink'
    user = line[1:4]
    group = line[4:7]
    other = line[7:10]
    d1 = 0
    if user[-1] == 's':
        d1 += 4
    if group[-1] == 's':
        d1 += 2
    if other[-1] == 'T':
        d1 += 1
    user = user.replace('s', 'x')
    group = group.replace('s', 'x')
    other = other.replace('T', 'x')
    d2 = parse_rwx(user)
    d3 = parse_rwx(group)
    d4 = parse_rwx(other)
    return str(d1) + str(d2) + str(d3) + str(d4)


def parse_rwx(data: str) -> int:
    d = 0
    if data[0] == 'r':
        d += 4
    if data[1] == 'w':
        d += 2
    if data[2] == 'x':
        d += 1
    return d


def extract_package_data(deb: str) -> Dict[str, Any]:
    """
    Extract hashes from a deb package
    """
    install_dir = join('/tmp', '.'.join(deb.split('.')
                                        [:-1]).split('~')[0] + '-install')
    files = []
    run_command_unhandled(f'dpkg -x {deb} {install_dir}')
    hashes = {}
    for x in listdir_recursive(install_dir):  # no dirs so
        pth = join(install_dir, x)
        if not islink(pth):
            bs_path = join('/', x)
            #data = run_command_unhandled(
            #    f'hashdeep {pth} | tail -n1 | cut -d, -f1,2,3')[0].strip().split(',')
            #hashes[bs_path] = {'size': int(data[0].strip()), 'md5': data[1], 'sha256': data[2]}
            hashes[bs_path] = hashdeep(pth)
    perms = run_command_unhandled(
        f"dpkg -c {quote(deb)} | tr -s ' ' | cut -d' ' -f1,2,6")[0].strip().splitlines()
    if '' in perms:
        perms.remove('')
    acls = ''
    attrs = ''
    for x in perms:
        perms = ls_to_octal(x.split(" ")[0])
        if perms == 'symlink':
            continue # TODO: handle symlinks
        owner = x.split(" ")[1].replace('/', ':')
        file = x.split(" ")[2]
        files.append(abspath(join('/',file)))

        #run_command_unhandled(
        #    f'chmod {quote(perms)} {join(install_dir, file)}')  
        chmod(join(install_dir, file), perms)
        #run_command_unhandled(
        #    f'chown {quote(owner)} {join(install_dir, file)}')
        chown(join(install_dir, file), owner.split(':')[0], owner.split(':')[1])
        if exists(join('/', file)):      
            #acl = run_command_unhandled(
            #    f'getfacl -Lp {quote(join(install_dir, file))}')[0].strip().replace(install_dir, '')
            acl = getfacl(join(install_dir, file), normalize_output=True).replace(abspath(install_dir) + '/.', '')
            acl += '\n\n'
            acls += acl
            #attr = run_command_unhandled(
            #    f'lsattr -d {quote(join(install_dir, file))}')[0].strip().replace(install_dir, '')
            attr = lsattr(join(install_dir, file), normalize_output=True).replace(abspath(install_dir) + '/.', '')
            attr += '\n'
            attrs += attr
    acls = acls.strip() + '\n\n'
    remove(install_dir)
    pkg = run_command_unhandled(f"dpkg -I {quote(deb)} | grep 'Package: ' | cut -d' ' -f3")[0].strip()
    dependancies = run_command_unhandled(f"apt-cache depends {quote(pkg)} | grep 'Depends: ' | tr -s ' ' | cut -d' ' -f3")[0].strip().splitlines()
    if '' in dependancies:
        dependancies.remove('')
    data = {}
    data['hashes'] = hashes
    data['acls'] = acls
    data['files'] = files
    data['dependencies'] = dependancies
    data['attrs'] = attrs.strip()
    return data


def extract_files_from(package: str, files: str | List[str], path: str) -> bool:
    """
    @param package: The name of the package
    @param files: The file(s) to extract
    @param path: The path to extract it to
    @return: A boolean indicating the sucess of the operation
    """
    if type(files) == str:
        files = [files]
    files = [x if not x.startswith('/') else x[1:] for x in files]
    log(f'Installing {package} to {path}', 'packages')
    if not exists(path):
        create_dir(path)
    [remove(join(getcwd(), x))
     for x in listdir(getcwd()) if x.endswith('.deb')]
    [remove(join(getcwd(), x))
     for x in listdir(tooling_dir) if x.endswith('.deb')]
    run_command_unhandled(f'apt-get download {package} 2>/dev/null')
    new = [x for x in listdir(getcwd()) if x.endswith('.deb')]
    if len(new) == 0:
        log(f'Failed to install {package} to {path}', 'packages', 'WARN')
        return False
    for deb in new:
        install_dir = join('/tmp', '.'.join(deb.split('.')
                           [:-1]).split('~')[0] + '-install')
        create_dir(install_dir)
        run_command_unhandled(f'dpkg -x {deb} {install_dir}')
        in_install_dir = listdir_recursive(install_dir)
        for file in files:
            if file in in_install_dir:
                copy(join(install_dir, file), join(path, file))
                if file in files:
                    files.remove(file)
        remove(install_dir)
    [remove(join(getcwd(), x))
     for x in listdir(getcwd()) if x.endswith('.deb')]
    [remove(join(getcwd(), x))
     for x in listdir(tooling_dir) if x.endswith('.deb')]
    if len(files) != 0:
        log(f'Files {files} were not found in {package}', 'packages', 'WARN')
        return False
    return True

def uninstall(package: str) -> bool:
    """Uninstall a package"""
    log(f'Uninstalling {package}', 'packages')
    package = quote(package)
    # TODO: can we make this not rely on apt so its like safe, or replace chunks of apt for functionality
    try:
        run_command_unhandled(f'apt-get autoremove -y {package}')
    except Exception as e:
        pass
    return True


def install(package: str | List[str]) -> bool:
    """Install a package"""
    if type(package) == list:
        for pkg in package:
            install(pkg)
        return True
    package = quote(package)
    log(f'Installing {package}', 'packages')
    run_command_unhandled(f'apt-get install -y {package}')
    return True

def get_all_packages() -> List[str]:
    """
    @return Installed packages
    """
    files = listdir('/var/lib/dpkg/info')
    if '' in files:
        files.remove('')
    files = [x.replace('.list', '') for x in files if x.endswith('.list')]
    files = [x.split(':')[0]
                for x in files]  # remove .list and :<arch> if present
    files = list(set(files))
    files.sort()    
    return files

def get_default_packages() -> List[str]:
    """
    @return Installed packages
    """
    default_packages = open(
        f'{baselines_dir}/packages').read().strip().splitlines()
    return default_packages

def get_installed_packages() -> List[str]:
    """
    @return Installed packages
    """
    packages = get_all_packages()
    default_packages = get_default_packages()
    stripped_all = {}
    charset = string.digits + ".-"
    for x in packages:
        l = x
        for y in charset:
            x = x.replace(y, '')
        stripped_all[x] = l
    stripped_default = {}
    for x in default_packages:
        l = x
        for y in charset:
            x = x.replace(y, '')
        stripped_default[x] = l
    diff = []
    for x in stripped_all:
        if x not in stripped_default:
            diff.append(stripped_all[x])
    return diff