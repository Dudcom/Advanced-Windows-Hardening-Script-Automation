# acl library
from os import getcwd
# fmt: off
import tempfile
from .cmd import run_command_unhandled, run_command
from .file_wrappers import exists, log, listdir_recursive, listdir, is_handled, join, baselines_dir, exclude_dirs, tool_root_directories
from shlex import quote
# fmt: on

def normalize_output(func):
    def wrapper(*args, **kwargs):
        new_kwargs = kwargs.copy()
        if 'normalize_output' in kwargs:
            del new_kwargs['normalize_output']
        output = func(*args, **new_kwargs)
        if 'normalize_output' in kwargs and kwargs['normalize_output']:
            output.replace(getcwd(), '').strip()
        return output
    return wrapper

def chown(file: str, user: str, group: str) -> bool:
    """Change owner of file"""
    if not exists(file):
        return False
    file = quote(file)
    run_command_unhandled(f'chown {user}:{group} {file}')
    return True

def chmod(file: str, perm_int: str):
    if len(perm_int) == 3:
        perm_int = '0' + perm_int
    if not exists(file):
        return False
    file = quote(file)
    run_command_unhandled(f'chmod {perm_int} {file}')
    return True

def chattr(file: str, attr: str) -> bool:
    if 'e' not in attr:
        attr += 'e'
    if not exists(file):
        return False
    file = quote(file)
    run_command_unhandled(f'chattr ={attr} {file}')
    return True

@normalize_output
def getfacl(file: str) -> str:
    if not exists(file):
        log(f'Failed to getfacl {file}', 'acls', 'WARN')
        return ''
    file = quote(file)
    return run_command_unhandled(f'getfacl -Lp {file}')[0].strip()

@normalize_output
def setfacl(acl: str) -> bool:
    f_path = acl.split("\n")[0].split(": ")[1]
    if not exists(f_path):
        #if not any(x in f_path for x in ['/usr/src/linux-headers', '/usr/lib/modules']):
        #    log(f'Failed to setfacl {f_path}', 'acls', 'WARN')
        return False
    with tempfile.NamedTemporaryFile() as tmp:
        tmp.write(acl.encode())
        tmp.flush()
        try:
            run_command_unhandled(f'setfacl --restore={tmp.name}')
        except:
            log(f'Failed to setfacl {f_path}', 'acls', 'WARN')
            return False
        return True
    

@normalize_output
def _getfacl_dir(dir: str) -> str:
    stdout, stderr, code = run_command(f'getfacl -RLp {dir}')
    if stderr:
        lines = stderr.splitlines()
        for x in lines:
            if not any(y in x for y in ['Permission denied', 'Operation not supported', 'such file or directory']):
                log(f'Failed to getfacl {dir}: {x}', 'acls', 'WARN')
    return stdout.strip()

@normalize_output
def getfacl_dir(dir: str) -> str:
    dir = quote(dir)
    if not exists(dir):
        log(f'Failed to getfacl {dir}', 'acls', 'WARN')
        return ''
    if dir == '/var':
        acls = ""
        sub_dirs = listdir('/var')
        for dir in sub_dirs:
            if dir not in ['run']:
                acls += _getfacl_dir('/var/' + dir) + '\n\n'
    else:
        acls = _getfacl_dir(dir)
    return acls.strip() + '\n\n'

def get_system_facls() -> str:
    facls = ""
    for x in listdir('/'):
        if x not in tool_root_directories + exclude_dirs + ['home']:
            acls = getfacl_dir(f'/{x}', normalize_output=True)
            facls += acls + '\n\n'
    return facls.strip() + '\n\n'


@normalize_output
def setfacls(acl: str) -> bool:
    # split acl into entries
    acls = acl.strip().split('\n\n')
    sys_acls = get_system_facls().strip().split('\n\n')
    if '' in sys_acls:
        sys_acls.remove('')
    if '' in acls:
        acls.remove('')
    diff = set(acls).difference(set(sys_acls))
    c = 0
    log(f"Setting {len(diff)} acls", 'acls')
    for acl in diff:
        c += 1
        if c % 100 == 0:
            log(f"{c}/{len(diff)}", 'acls', 'DEBUG')
        setfacl(acl)
    return True

@normalize_output
def lsattr(file: str) -> str:
    if not exists(file):
        return ""
    file = quote(file)
    return run_command(f'lsattr -d {file}')[0].strip()

@normalize_output
def lsattr_dir(dir: str) -> str:
    if not exists(dir):
        return ""
    dir = quote(dir)
    files = listdir_recursive(dir)
    attrs = ""
    for file in files:
        file = join(dir, file)
        if exists(file) and is_handled(file):
            attrs += lsattr(file) + '\n'
    return attrs.strip()