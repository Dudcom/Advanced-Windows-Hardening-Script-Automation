from os.path import getsize
from hashlib import sha256, md5
from typing import Dict, List, Callable
from .cmd import *
from .file_wrappers import *

def hshfile(filename: str, mode: Callable = sha256) -> str:
    """
    Hashes a file using the hashlib callable specified
    """
    h  = mode()
    b  = bytearray(128*1024) # using a buffer to load chunks at once instead of the entire file - multiprocessable
    mv = memoryview(b)
    with open(filename, 'rb', buffering=0) as f:
        while n := f.readinto(mv):
            h.update(mv[:n])
    return h.hexdigest()

def hashdeep(file: str) -> Dict[str, str]:
    return {'size': getsize(file), 'sha256': hshfile(file), 'md5': hshfile(file, md5)}

def hashdeep_from_line(line: str) -> Dict[str, str]:
    data = line.split(',')
    return {'size': int(data[0].strip()), 'md5': data[1], 'sha256': data[2]}

def hashdeep_from_file(file: str) -> Dict[str, Dict[str, str]]:
    data = open(file).read().replace('\n\n', '\n').strip().splitlines()
    res = {}
    for x in data:
        if x.strip() == '':
            continue
        res[''.join(x.strip().split(',')[3:])] = hashdeep_from_line(x.strip())
    return res


def files_from_hashdeep(file: str) -> List[str]:
    """
    @param file: hashdeep file
    @return: list of files from hashdeep file
    """
    data = open(file).read().strip().splitlines()
    data = [''.join(x.strip().split(',')[3:]) for x in data]
    return data


def create_hashdeep(dir: str) -> str:
    """
    @param dir: directory to create hashdeep for
    """
    files = listdir_recursive(dir, show_files=True, show_dirs=False, exclude_dirs=[])
    hashes = []
    for x in files:
        file = join(dir, x)
        if exists(file) and is_handled(file):
            de = hashdeep(file)
            hashes.append(f'{de["size"]},{de["md5"]},{de["sha256"]},{file}')
    return "\n".join(hashes)
