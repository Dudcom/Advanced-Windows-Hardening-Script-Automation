from os import symlink as syml, listdir as lsdir, walk, remove as remove_file, unlink, PathLike, stat as stat_file
from os.path import abspath, join, exists as exsts, isdir, islink, realpath, dirname
# rmtree exists on linux
from shutil import copytree, rmtree, copyfile as copyf
from pathlib import Path
from time import time_ns
from typing import *
from .cmd import *

def listdir(path: PathLike):
    """List files in a directory"""
    # path = process_path(path)
    if not exists(path):
        return []
    return lsdir(path)


def copyfile(src: str, dst: str) -> bool:
    """Copy file"""
    # src = process_path(src)
    # dst = process_path(dst)
    if exists(dst):
        remove(dst)
    if not exists(abspath(join(dst, '..'))):
        create_dir(abspath(join(dst, '..')))
    copyf(src, dst)
    return True

def is_socket(path: str) -> bool:
    """Check if a file is a socket"""
    # path = process_path(path)
    if not exists(path):
        return False
    return stat_file(path).st_mode & 0o170000 == 0o140000

def is_fifo(path: str) -> bool:
    """Check if a file is a fifo"""
    # path = process_path(path)
    if not exists(path):
        return False
    return stat_file(path).st_mode & 0o170000 == 0o010000

def is_block(path: str) -> bool:
    """Check if a file is a block"""
    # path = process_path(path)
    if not exists(path):
        return False
    return stat_file(path).st_mode & 0o170000 == 0o060000

def is_char(path: str) -> bool:
    """Check if a file is a char"""
    # path = process_path(path)
    if not exists(path):
        return False
    return stat_file(path).st_mode & 0o170000 == 0o020000

def is_handled(path: str) -> bool:
    """Check if a file is unhandled"""
    # path = process_path(path)
    if not exists(path):
        return False
    try:
        if islink(path) and (not exists(realpath(path)) or (realpath(path) + '/') in (path + '/')):
            # print(f"{realpath(path)} {path}")
            return False
        f_stat = stat_file(path).st_mode & 0o170000
        return f_stat != 0o140000 and f_stat != 0o010000 and f_stat != 0o060000 and f_stat != 0o020000
    except Exception as e:
        if 'many levels' in str(e):
            return False
        raise e

def ignore_unhandleable(path, names):
    ret = []
    # huge slowdown... but we need to ignore sockets
    for x in names:
        if not is_handled(join(path, x)):
            #log(f'Cannot copy unhandleable {path}/{x}', 'copy', 'WARN')
            ret.append(x)
    return ret

def copydir(src: str, dst: str) -> bool:
    """Copy directory"""
    # src = process_path(src)
    # dst = process_path(dst)
    if not exists(abspath(join(dst, '..'))):
        create_dir(abspath(join(dst, '..')))
    copytree(src, dst, dirs_exist_ok=True, ignore=ignore_unhandleable)
    return True


def copy(src: str, dst: str) -> bool:
    """Copy file or directory"""
    # src = process_path(src)
    # dst = process_path(dst)
    if exists(dst):
        remove(dst)
    if not is_handled(src):
        #log(f'Cannot copy unhandleable {src}', 'copy', 'WARN')
        return False
    if isdir(src):
        copydir(src, dst)
    else:
        copyfile(src, dst)
    return True


def remove(path: str) -> bool:
    """Remove file or directory"""
    # path = process_path(path)
    backup(path)
    path = abspath(path)
    if exists(path):
        if isdir(path):
            if not islink(path):
                rmtree(path)
            else:
                unlink(path)
        else:
            remove_file(path)
    return True


def create_dir(path: str) -> bool:
    """Create directory"""
    # path = process_path(path)
    if not exists(path):
        Path(path).mkdir(parents=True, exist_ok=True)
    return True


def listdir_recursive(path: str, exclude_dirs: List[str]=[], show_dirs: bool=False, show_files: bool=True) -> List[str]:
    """Get all files in a directory, recursively, excluding any directories in excluded_dirs"""
    # NOTE: would like impl check
    path = abspath(path)
    if not exists(path):
        return []
    all_files = []
    for x in listdir(path):
        if x not in exclude_dirs:
            # from comment in https://stackoverflow.com/questions/3207219/how-do-i-list-all-files-of-a-directory
            files_in_dir = []
            for root, dirs, files in walk(f"{path}/{abspath(x).split('/')[-1]}"):
                if show_files:
                    for file in files:
                        files_in_dir.append(join(root, file))
                if show_dirs:
                    for dir in dirs:
                        files_in_dir.append(join(root, dir))
            all_files.extend(files_in_dir)
    files_in_cwdir = listdir(path)
    for file in files_in_cwdir:
        if not (isdir(join(path, file)) and not show_dirs) and not (not isdir(join(path, file)) and not show_files):
            all_files.extend([join(path, file)])
    return [x.replace(path + "/", "") for x in all_files]


def log(message: str, file: str, priority: str='INFO') -> bool:
    """Log a message to a file"""
    # file = process_path(file).split('/')[-1]
    codes = {
        "ACTION": ["\e[1;31m", True],
    }
    pth = f'/tool-log/{file}'
    create_dir('/tool-log')
    open(pth, 'a').write(f'[{priority}] {message}\n')
    alarm = False
    if priority in codes:
        alarm = codes[priority][1]
        #priority = f'{codes[priority][0]}{priority}\e[0m'
    print(f'[{priority}]:{pth} {message}')
    if alarm:
        print('\a')
    return True


def write(file: str, data: str) -> bool:
    """Write data to a file"""
    # file = process_path(file)
    backup(file)
    open(file, 'w').write(data)
    return True


def create_file(path: str) -> bool:
    """Create a file"""
    # path = process_path(path)
    if not exists(path):
        open(path, 'w').close()
    return True

def symlink(src: PathLike, dest: str):
    #log(f"Symlinking {src} to {dest}", 'symlink', priority='DEBUG')
    if not exists(dirname(dest)):
        create_dir(dirname(dest))
    if exists(dest):
        backup(dest)
        remove(dest)
    # src = process_path(src)
    # dest = process_path(dest)
    try:
        syml(src, dest)
    except Exception as e:
        if 'Operation not permitted' in str(e):
            return False
        raise e
    return True


def exists(path: PathLike) -> bool:
    """Check if a file exists"""
    # path = process_path(path)
    return exsts(path) or islink(path)

def append(file: str, data: str, repeat=True) -> bool:
    """Append data to a file"""
    # file = process_path(file)
    if not repeat:
        if exists(file):
            f = open(file).read().splitlines()
            if data in f:
                return True
    backup(file)
    open(file, 'a').write(data + '\n')
    return True


def backup(file: str) -> bool:
    """Copy to /backup, prefix with timestamp"""
    # file = process_path(file)
    if (not exists(file)) or islink(file):  # we too late... :<
        return False
    if file[0] == '/':
        file = file[1:]
    if file[-1] == '/':
        file = file[:-1]
    if any(file.startswith(x) for x in tool_root_directories + exclude_dirs):
        return False
    if not exists('/backup'):
        create_dir('/backup')
    if not exists('/' + file):
        return False
    parent_dir = abspath(join('/' + file, '../'))
    if parent_dir[0] == '/':
        parent_dir = parent_dir[1:]
    bdir = join('/backup', parent_dir)
    if not exists(bdir):
        create_dir(bdir)
    copy('/' + file, join(bdir, f"{file.split('/')[-1]}-{time_ns()}"))
    return True

# Operating System (Ubuntu22, Ubuntu20, Debian)
op_sys = open('/etc/os-release').read().splitlines()
op_sys = [x for x in op_sys if x.startswith('NAME=')][0].split('=')[1].replace('"', '')
if op_sys == 'Debian GNU/Linux':
    op_sys = 'Debian'


if op_sys == 'Ubuntu':
    version = open('/etc/os-release').read().splitlines()
    version = [x for x in version if x.startswith('VERSION_ID=')][0].split('=')[1].replace('"', '').split('.')[0]
    op_sys = f'Ubuntu{version}'




# Directory of utils folder
utils_dir = abspath(__file__ + '/..')

# Directory of tooling folder
tooling_dir = abspath(utils_dir + '/..')

# Directory of files folder for this os
__files_dir = abspath(utils_dir + f'/files/{op_sys}')

# Directory of baselines folder for this os
baselines_dir = abspath(__files_dir + '/baselines')

# Directory of configs folder for this os
configs_dir = abspath(__files_dir + '/configs')


tool_root_directories = ['baselines', 'backup', 'tool-log', 'media', 'mnt', 'tmp']
exclude_dirs = ['sbin', 'bin', 'lib', 'sys', 'proc', 'snap', 'run', 'swap.img', 'lost+found', 'swapfile', 'rofs', 'lib64', 'lib32', 'vmlinuz.old', 'vmlinuz', 'initrd.img', 'initrd.img.old']
for x in tool_root_directories:
    if not exists(f'/{x}'):
        create_dir(f'/{x}')

    
CLIENT_OUT_DIR = abspath(utils_dir + '/../client-out')
user_pwd = '^Z>+82EvIr)pP9'