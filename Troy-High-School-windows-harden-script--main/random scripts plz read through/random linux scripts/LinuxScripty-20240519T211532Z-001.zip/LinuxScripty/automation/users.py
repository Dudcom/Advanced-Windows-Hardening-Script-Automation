# fmt: off
# import crypt
from random import SystemRandom
from os.path import abspath
from sys import path
path.append(abspath(__file__ + '../../'))
from utils import *
import datetime
# fmt: on
MAX_PASWORD_AGE = 90
MIN_PASSWORD_AGE = 5
WARN_PASSWORD_AGE = 7
INACTIVE_DAYS = 30

known_groups = 'root daemon bin sys adm tty disk lp mail news uucp man proxy kmem dialout fax voice cdrom floppy tape sudo audio dip www-data backup operator list irc src gnats shadow utmp video sasl plugdev staff games users nogroup systemd-journal systemd-network systemd-resolve crontab messagebus systemd-timesync input sgx kvm render syslog tss uuidd tcpdump _ssh landscape fwupd-refresh admin netdev lxd rtkit bluetooth whoopsie avahi lpadmin scanner saned colord geoclue pulse pulse-access gdm'
hardened_groups = {
    # only admins can add devices, forces authorization for usbs
    'plugdev': ('admin',),
    'admin': ('admin',),  # ...
    'sudo': ('admin',),  # ...
    'adm': ('admin', ['syslog']),  # system logs
    'lpadmin': ('none',),  # printer administration
    'dip': ('admin',),  # connecting to internet via modem
    'cdrom': ('admin',),  # disk access
    'netdev': ('admin',),  # can connect/switch internets
    'fuse': ('admin',),  # mounting filesystems
    'fax': ('none',),  # ok you can mfing fax you users, im so nice
    'sambashare': ('admin',),  # network shares
    'audio': ('admin', ['pulse']),  # using audio devices.....
    'floppy': ('admin',),  # OK WHO THE ACTUAL FUCK USES FLOPPY DISKS
    'dialout': ('admin',),
    'tape': ('none',),
    'video': ('admin',),
    'lxd': ('admin',),
}
known_users = 'root daemon bin sys sync games man lp mail news uucp proxy www-data backup list irc gnats systemd-network systemd-resolve messagebus systemd-timesync syslog _apt tss uuidd tcpdump sshd pollinate landscape fwupd-refresh lxd rtkit dnsmasq whoopsie usbmux avahi cups-pk-helper saned colord geoclue pulse gdm'
known_users = known_users.split(' ')


sr = SystemRandom()

# jFT - rounds=11
"""

def mk_salt(): return '$y$jFT$' + ''.join(sr.choice(crypt._saltchars.replace('/', ''))
                                          for _ in range(21)) + '.'


def hash_pwd(pwd, salt):
    return crypt.crypt(pwd, salt)


def mk_passwd(pwd, rounds=1):
    salt = mk_salt()
    for _ in range(rounds):
        pwd = hash_pwd(pwd.rstrip(salt + '$'), salt)
    return pwd
"""

"""
def fetch_password():
    import os
    os.system('echo "bob1:^Z>+82EvIr)pP9" | chpasswd')
    return os.popen('cat /etc/shadow | grep bob1').read().split(':')[1].strip()
"""
global counter
counter = -1
pwds = ['$y$jFT$wZoSiIJO6EAXSkjeTCLwJ1$.TnvmMEpF1ipiCHX0U6aWFrTKV6lPY5ZiIdfaPAs.PD', '$y$jFT$4/GBovIQ88miUFBkmNXbu0$WKdswOoQ8eIrHR6VKdIWhmaSRTFl/sQwe6qkWyCyNK1', '$y$jFT$eRMwXI5jZKBVm9yU9OpSq/$hvQ0k8HXlvUAwKeObXjulV1yib2t6orkG5MhBPI9.85', '$y$jFT$jfNETHawmRf7Ht8obhe0O/$MKkC4ZEM87sL60M1JBfLhbRRq8wZjAnSiAQHWRCe7lB', '$y$jFT$/FZheFbtjqmsEWm46JgDs.$Q5dYgR4no4JXNOV0KFHH/5T.f6.0gvSTKQBMh.FYCv0', '$y$jFT$eJaoeVzeHqws11.mrObVJ1$B7n6aSIrwJzrGzqywekNxmapL/pcRVkwDFO6Qw6R6b6', '$y$jFT$c/hYz2G4GSvFx5HFoMGMW1$y/jCBf78cbKnXUtWadeB8g16EKr7j0CtN.2IvVqkQsA', '$y$jFT$QYiUZSpFYSVVPytVFZsiG1$/E.wQVsOviHhrq54h80CtF9ncK6ValUwTegFq1ED2OB', '$y$jFT$e3Te3nblDvrSNCZHcu7z8/$JOG.m.NXyYlf4R1uEfKZAQVs.jRyUa1EYSdhnMrdW97', '$y$jFT$lf/gPITBuEb5zK5WpjVSF.$BiWR4pILBNgx7nnIvtBtEvtUJXSmT4W/FA/IygDlakA', '$y$jFT$MGZJTKDDmrK4i6/Mse6Wc1$X3owX8GD6vOE6m//ryN9XZjuv8HAek8/VSSDQUsjYOC', '$y$jFT$6XOMWbOswNzthK0ud5.fK1$P7/B183B1dqXhBNwKxXUyn/YkRARqBzZBU/k6JI/3YB', '$y$jFT$dRJ/yUnzMBXRDv3FnEHFI.$tcU52iF0Q9QlJM4LANHMwCeXllUWrJGW6qNO3.P88H0', '$y$jFT$trVe4nfg/8b0/P8lB7mcd0$NCZagBKAR.bvObkkpRugXDdAVRxCZbo/s8Tm9/nu8N3', '$y$jFT$evOUElYx6XHriKsVkrwjl.$jBp0LeTiqjE3WOiZ7Njq.6GA9oWe44CpWUBO2LooiM.', '$y$jFT$HqePIGusWLSCyxaBFcqA21$MYzal1dN9YwgUzOkv3o2AmKrM1AcLpab0h9SlMFZxU9', '$y$jFT$kyRTBAnMfLIKqFk.pLSVY.$2fnevmgrXMgzvMN.RRveUdHH88IuUt1Wz6wooGC.T3.', '$y$jFT$IPqv6zpdovpjP7yHMZ.ia.$AsUJVyDICRilIl/rI7iu9Mb4IWmLeQstXiICR2nCnZ.', '$y$jFT$JYmF.aeZPGvB/o54n6t.g0$sINdDffaOjxyHid.85C8mgcDGw/bjWETk0JQc43l5r2', '$y$jFT$F6Kdrf3ZuYXYE3xKeszu0.$a8kPVwdB5tpRAlvCrcu1xKLGbhv3DJxJviqsij72S76', '$y$jFT$AamJMO9YFPCobouFrti39/$HN9HkD4l0r10heH7OotUmT52B59pJGJqCLSA4v90h96', '$y$jFT$OHClZhNA5Q3ZCRdxLiZfS.$R2gJe8186pf7mKcq1726szDZxk3s3hZkGYbjw7z1bT7', '$y$jFT$RZdTwstHuyj9WMCaY5k560$LFNXCjWeQn7eifiB077t/FAa8oka.Sy6z2NJAuUKT/D', '$y$jFT$cIsdauaKyE87TIidIPARo.$paueYInZu2pTqePkqI0DJu9JoZ7JzvSLheM8sQahoKB', '$y$jFT$vixqxIiYJXGXPEMwRh4tM1$gcJCBxUgTllOjiuGO.dob7qf08dDDgdie.Ih1P7Sok8', '$y$jFT$RiuD1eKNBhQokkVLKVm3C1$vRVjcNJY44wLJKVxKx6psaYLc.oDamZwzf1DcPb9MW/', '$y$jFT$yuxcHQUyKCVNxIfUKnJ/p1$Ai3IOb5/NUQOi.ZpXJRfkyVnCl/jIfo.MOqWj3DTSA2', '$y$jFT$Ct2ttm3wsYPrSiVjA4OAI.$Ni3ys9.FHNVS0/WKa7KBd1DVFZwTXCs/P0.klSnQaJ.', '$y$jFT$ZYMGrR5mY.cGyk51Kkpk11$iAj2z.Ti9r/GJuY8R3VVXmJYxLA/vo9nEC9Yt2K01X0', '$y$jFT$afOlLkVEH1dZ4AwT9E.vd1$g8eSrYkAHlnMxCvUkQJp1EDcN6t7oTJaVdoQo0bAJ54', '$y$jFT$yzVBS0oNCxyEVEQeVbWKv.$2sv1faohFTT9uUwTjkPLuC/idqFS5jHBxbIeyZxWz65', '$y$jFT$NONCZ3rFPHadTEnzPn7p./$oWTQ31/MUYEvFByDu1o/P8Dvfynp4A/jUMaazQhgDn3', '$y$jFT$MgQWoG6Q1vGXjegyKIFDj/$hr99/M.88bIuml5ERUDm2S61hAPGS.NliOm7BeNdeY6', '$y$jFT$0XapdqtG.F3gCneiZ899U0$4xE//2Gjrd6idqGOMHjXuVubidn5uggI5bbeDFEhlfB', '$y$jFT$Sqyj1vfd3kMNWvvMzve641$6hNNhuTrKzl6K03mWHaDTEypQ9ZFvjo1O5bSR5Xps3B', '$y$jFT$dvylmiAxUXlV6YWQUcaY.0$SKT0RyNBVf5LMPlGaOAsIOlX7GGNTjP3fVPcHQO4Az1', '$y$jFT$te6TYTqRhLJiQfyRG1w0b.$dUjBC9IDntE6G.jUe4v5cqPzOH7btC5..L9MJNTFUP9', '$y$jFT$iAZ8.u.E2JREEJvmXGqit.$ZtpDjOB5RgwGSzqht9hGnYpwffnRf5oZ3hS/Fs/3B16', '$y$jFT$K42o6YYg.E9O0skW4bYQL0$MiYaQiD1vAP9sRyE9ctP73rGCPfYz2U7dvzbMPkKTt7', '$y$jFT$XYvaQqf1ifNs2HJpMiY.s1$ZuEcCvGDa.nquBNB9yK/sUBLZurhePxJLLhBtz7ldX2', '$y$jFT$kZ.EMNdAa2DZ/P/r1l7AJ.$FFmpkLpveKKHwzeOFpZlbwIzOfAShRmjQOiHMBo/hwA', '$y$jFT$WKDyUZwcT2XoN2Ba474Ro0$NRPVIKHtOewnXrdXMTyyuOQ8vVmkkXFSZdSqA3KRyB5', '$y$jFT$bwvEEJ9V9alP/3ejkwZMe.$4oNkPH9OZZIkoz.LuVGHjB6FuXIcMOFVYhVhqbsCPJ2', '$y$jFT$vRw9VwfKiti3GHyWbXOj21$t6q9034bPImt6GmMf61DxXDlNhTjrlod0JN7zANP3M9', '$y$jFT$ootU9LGB4ZokfFMw/3nFF.$Pn4qIDG3pNx5fhCK/EcnItkEvBeJbEkgmOB7tTMqKtA', '$y$jFT$ftQZYqaBKVsmq5cTD1tbf0$cff9Lsba0oVUecBFn19BRNb80CmvdgnePmUY7rkSt07', '$y$jFT$GeQBlA/J0D.IwoknCCzkL/$7L/2X4os1BkSULeLTS1BrekXl12hssMD2B5RKMUePU5', '$y$jFT$ki56k2POt5hgy7..6R0.v0$.A2UJ2Hp/Rnq1ng1W6LVAuIhiVlRbo3w9ulzB1Ckzp0', '$y$jFT$9.rmV0l2M5Dvcd8vJQ8Qb1$NOfxTfNjhSFcs8MBsSGH0zMh3uaZLrc1xP7.l1VYa/1', '$y$jFT$YuEky0kjE9EVw.QG1Jz2L0$/JntJR7LALu1GwvmuVXAqVc/5Fxvcrh6o7NcSxt/6V1',
        '$y$jFT$y.e0s1M94W8ZHWzuwGW9D/$FwneXeXYkYYZ7cdowBWX/1Xge53BXWaol.d7DAuOJY5', '$y$jFT$zvrXO0X5lnXepDgSYzQZ50$Co1rTRShWioX6mOVD8IO/yP09JBCYA3aOpSDnoug378', '$y$jFT$rOfOtQQhvj9gbAjLZtjEU/$v1f.YQYkZXwdMIjP6fYCc1iCW7/IknP15b18nptbMd9', '$y$jFT$q4kP1RMT/ApAz3hWs6oBL/$c.l7y0z5L7wDAPiregeVjJr1u7tn.KoY64dBlkAvkk6', '$y$jFT$K8ColOtz2EpwCA/4Mw6.s/$wZj52QPYpHGt6vnph0o7mTXY.PqhbStHLbbJtTBJxN9', '$y$jFT$MeTpjHCGAh3YKQTGNctUu.$ksuWljYJFJUsb8aXhmzTitlp5vHTdyQhTQnMVHskza5', '$y$jFT$pdO.CYp6mi0JOJPXraanX/$PohHBpwEAmx4H7PjBuNC1mm1OamWf4aMH43U4lA9SB3', '$y$jFT$1UkKfgL3AFcbR/hBcdjrb0$O5h5gMGwoT92866D22IGm3KPCCM7tPdUcOpDUnFmum2', '$y$jFT$EKISzBoh3So76CHNzOLEW1$vSST9.xmGowzpx6UILKktZa1RedmUEacIpd8IX/fSJD', '$y$jFT$gOCCdFnVODjv5AKLFrEj50$MxSQ2.CzIJDNeuWc2aMljL3h0HRGlf5Lju.avxqHmQ0', '$y$jFT$abDfi/9HOmwRs5ozsy4Na/$oQt8Wt1o3AobSztic9FJJ3mTWh3CR/.O9civXK7Q3SD', '$y$jFT$cD5VQejC7yX36W2rsoc/m.$4/1eF3k4XWoyLu0YETyypr6ThO6M.PqMSWnUuP66DL6', '$y$jFT$6povyIIUgFdiU3IA07es80$dvmtTe3YkhH56VvFYn/bs/u1nXUiIG4bT9KDJkzcH/7', '$y$jFT$UlFcN2q1B4CAX96fKtq3g1$sDZqXb5vKJxAVTtBNP9LOtE4wxhDQ3cUWPYi1WzFTH.', '$y$jFT$blmsjoWfwJz8j43f8wCrW.$AwNctTg.K8ULIaY6SNIvNL3ImYXjnRRkRMV5TK0ci5.', '$y$jFT$jR6YNTjzFVSuqRzj/.kfy.$le.iww19X07NbHBTBcxlWnS0xt8PKlNwDyiU/W0bKgA', '$y$jFT$QSEyfMaZGwBC9/vZbykcA/$kaRIIofFg8wEkOwRoqaTLzPaLmu1WZAD6eT8XQGAR73', '$y$jFT$8WVQgRsL61ssstYs.g1M50$cbDD3g0ztYe6LAHZbgtjK9p5zVDMV0NLYxpk8Bzsr4C', '$y$jFT$CH.lBwtaE5HRxRa3W7t2G0$ErK81Rm3wOuL2ArLCrnDZeqlwzpf3yihuBQCjSTpZs1', '$y$jFT$taNyQhiuH28TZ5xMLTOaW1$8LTrRTwDv.6LeqXYiQ9zBkIOCAa.DDou6a4HnA3ksV9', '$y$jFT$IHtDe16YxnR1iL.gJxhG3.$NG/qvlsGkyvDDYWR/uNa2ehKkBOmy27yvoy8fpPQq38', '$y$jFT$giFvDpYAd.eOTzZlZOUwb1$/4Nwkt2KBb3O51MKY92WPaE2Wx42NyOaiCCWtCD8Vn/', '$y$jFT$0eoeLWzZq7JKEufx3znm7.$K3AXmjYelaPppETJ9ls7axv/VXHNf21BZex1jdWLo/0', '$y$jFT$0lRQnqLrhC2Gl58k4s3lc.$gGBAvXbadHKYtqcbv9/w3JhyqIqHM2tLVH7nOxIiFW9', '$y$jFT$fiVJBuR5NTPnQ.pQ5r17V/$zba6V.gFwLl9gWV4Pts/aQitOT7VkFrrKzvn1rRE6p/', '$y$jFT$OjEFPyeEocoU3kh2XojwA1$RVBbtA0xfUCwX.8nWKSZL8h5skbOyHsqROSveZbxow8', '$y$jFT$fJFw1FIpnuI9runD.CEue0$HOz7qO5tKuWSxUPU/DWbq/1esqv2BoCsJnIMtdrtsS4', '$y$jFT$kzvrkKLwR0WnIvKCYgo9O/$ET2ZNv97ZCWaVGRpMXJOjMlFdCat3MsHuVNut9t1p73', '$y$jFT$lnQPFxIvjPB5ohTPCeiKn.$XcIecpHMsb1Dbc5op5BxA8wCv9fu3FPLmVbHUYvJdZ5', '$y$jFT$n2Wq0/7KNsBuN1Am5Uwbk/$3EST9WPigTzuUKYYdr9coNu1ocnWwv5KSqwmiG0o7lB', '$y$jFT$AQUx6knKOqkI.hkUr7p780$RVuu2Fmfv3oBFzRczR6/kYmKfNpT66II8T0dZefUzfD', '$y$jFT$XD/Sgdm1FrTHHi.rbPvQs0$EZK255E.JCdiTLdhCQQUA0OYoKbtnpyJVdwh4tCO6v4', '$y$jFT$zJ1RqswziihQTc4ix/dJP/$o7kLHhuEkLEPzSDZiZ24Kf8e0ToroL0AzUf7mEgHUc0', '$y$jFT$TLwmUUfOeRLb7Fzp1BQDc1$JOZjtSyY5EiYdFDKrk6rblstmZe0Gfk0PDBW5WQHCl1', '$y$jFT$lNFcEXOLmrk1kimuYvE66.$vjKg4eKFPlyrvmv1HLbFzCHQ/zt4jdoOuUjGks/Fx7C', '$y$jFT$ilSjx.rzuLmP7L7gexffg/$PE2iq.IriLJVN55pTHta4ejJxp2rf/5lrb6RZFeINjD', '$y$jFT$cuV4XLkIX2qx0UJSODaoo.$CRB/HLijduvAP618/lmMMiSb.jsyISRiz22nK2Jj4gC', '$y$jFT$c2Ogs/GYAvZfQAbYfXhBC/$RqlwrRflGTwgqJJDhLrnAmOFWnHLRk66VRzI2LIDgf9', '$y$jFT$Wm0DiaR2x9SPT.pVrdkZw.$C2dInm4tSxBpx8q3ASA/Z5TCVYhB.C8aki9j0YGs8Q8', '$y$jFT$SbIhxvpkPDZaHD26E6Joh0$BiNOPHYbfQ6A6L82LPllWo8FNetKen0jTYK6HxIBL35', '$y$jFT$3kwYqeXBiUhhP1SBejM9V1$KOeQwJ1ii1oW47/fYzQX3RTV2jcnwOfYhQAIj14CoF5', '$y$jFT$0txOaLmb2LOWheP53E3Jt/$EoroHujvuO5isYuzKAJRsiZAnaMU.6UBjM1Ta.EhQI3', '$y$jFT$VmhkJD6UQsPH2MCgEKLUy/$ilJ2CDBftqAl70nO59tZrOkv19Aq3C.FlDiQEVgnhA4', '$y$jFT$BNybNKH5VRucHmG4mTKIA0$hF74w3JIkolVhqXcIW83D2AkwuRgN2Hyrv2vfAWrEc4', '$y$jFT$.bMX2skrHIpIJqXAXJCY.0$AWWRVN4R2/T.6zDXjJBHAC8mAkHlwWHlW/x2.saiMP7', '$y$jFT$jczVFWN3JlxOG4QCcLNIS.$xHvqmQT4YhWlonjzVS0lxekZG0vOfYHqpgg7wppLS7.', '$y$jFT$T.xapbNy2H5MKC03Pdwve0$4otIzPC4qA2XseYcjmdiOrVlqS6yytxnuB6NDYMsTM9', '$y$jFT$x6co0X.UZByaxE0xB2e50/$Kd.e6qwIc7tGgCvqiIPfxtdXfqG0Mw0QJa6YLWma9F1', '$y$jFT$GfxZa2sUprtRrofNKLoFd.$DAV3HUddE0IdAzdzHGtrmT5EyH7Sr1x2993WEji51o9', '$y$jFT$MfNAxN0wm0Q55SGAp0Ont0$AhmZDaNNqxUgzlBYSGHD95XEQkMo66yfBAs5vKzBv29']


def mk_passwd(*args):
    # hash of '^Z>+82EvIr)pP9'
    global counter
    counter += 1
    return pwds[counter % len(pwds)]


def parse_gshadow_line(line):
    """Parse a line from gshadow"""
    data = line.split(':')
    groupname = data[0]
    password = data[1]
    admins = list(data[2].split(','))
    if admins == ['']:
        admins = []
    users = list(data[3].split(','))
    if users == ['']:
        users = []
    return [groupname, password, admins, users]


def parse_gshadow_file():
    """Parse a group password file"""
    groups = []
    data = open('/etc/gshadow').read().splitlines()
    if '' in data:
        data.remove('')
    for x in data:
        groups.append(list(parse_gshadow_line(x)))
    return groups


def parse_group_line(line):
    """Parses a line of /etc/group"""
    line = line.split(':')
    groupname = line[0]
    pwd_location = line[1]
    gid = line[2]
    members = line[3].split(',')
    if members == ['']:
        members = []
    return [groupname, pwd_location, gid, members]


def parse_group_file():
    """Parse the group file"""
    data = open('/etc/group').read().splitlines()
    if '' in data:
        data.remove('')
    groups = []
    for x in data:
        groups.append(list(parse_group_line(x)))
    return groups


def parse_passwd_entry(line):
    """Parse a line from the passwd file"""
    data = line.split(':')
    username = data[0]
    pwd_ref = data[1]
    uid = data[2]
    gid = data[3]
    gecos = data[4]
    home = data[5]
    shell = data[6]
    return [username, pwd_ref, uid, gid, gecos, home, shell]


def parse_passwd_file():
    """Parse the passwd file"""
    data = open('/etc/passwd').read().splitlines()
    if '' in data:
        data.remove('')
    users = []
    for x in data:
        users.append(list(parse_passwd_entry(x)))
    return users


def parse_shadow_line(line):
    """Parse a line from the shadow file"""
    data = line.split(':')
    username = data[0]
    pwd_hash = data[1]
    last_changed = data[2]
    min_days = data[3]
    max_days = data[4]
    warn_days = data[5]
    inactive_days = data[6]
    expire_days = data[7]
    # field 9 unused
    return [username, pwd_hash, last_changed, min_days, max_days, warn_days, inactive_days, expire_days, ""]


def parse_shadow_file():
    return [list(parse_shadow_line(x)) for x in open('/etc/shadow').read().split('\n') if x != '']


def purge_extrausers():
    """Remove extrausers"""
    uninstall('libnss-extrausers')
    remove('/var/lib/extrausers')


class Passwd:
    def __init__(self):
        self.users = parse_passwd_file()
        self.next_uid = int(max([x[2] for x in self.users])) + 1
        self.next_gid = int(max([x[3] for x in self.users])) + 1

    def delete_user(self, username):
        """Delete a user"""
        for x in self.users:
            if x[0] == username:
                self.users.remove(x)
                return True
        return False

    def clear_gecos(self):
        """Clear the gecos field for all users"""
        for x in self.users:
            x[4] = ''
        return True

    def no_login_user(self, username):
        """Set a user to have no login"""
        for x in self.users:
            if x[0] == username:
                x[6] = '/usr/sbin/nologin'
                return True
        return False

    def lock_user_login(self, username):
        """Lock a user"""
        for x in self.users:
            if x[0] == username:
                x[6] = '/bin/false'
                return True
        return False

    def unlock_user_login(self, username):
        """Unlock a user"""
        for x in self.users:
            if x[0] == username:
                x[6] = '/bin/bash'
                return True
        return False

    def set_passwds_to_shadow(self):
        """Set all passwords to shadow"""
        for x in self.users:
            x[1] = 'x'
        return True

    def _find_colliding(self, idx):
        uids = {user[0]: user[idx] for user in self.users}
        if idx == 2:
            name = 'UID'
        elif idx == 3:
            name = 'GID'
        for x in uids.copy().values():
            if list(uids.values()).count(x) > 1:
                # collision
                users = [user for user in uids.keys() if uids[user] == x]
                if any([user in known_users for user in users]):
                    # system account involved
                    for user in users:
                        if user not in known_users:
                            if name == 'UID':
                                # assign new uid
                                uids[user] = str(self.next_uid)
                                self.next_uid += 1
                                log(
                                    f'Assigned new {name} {uids[user]} to user {user}', 'users', 'ACTION')
                            elif name == 'GID':
                                # assign new gid
                                old_gid = uids[user]
                                if old_gid == '65534':
                                    # already nogroup
                                    continue
                                uids[user] = str(65534)  # group nogroup
                                log(
                                    f'Assigned new {name} {uids[user]} to user {user} (old gid was {old_gid})', 'users', 'ACTION')
                else:
                    # no system account involved
                    log(
                        f"{name} collision detected for users {', '.join(users)}", 'users', 'ACTION')
        # update users
        for user in self.users:
            user[idx] = uids[user[0]]
        return True

    def find_colliding_uids(self):
        """Check for colliding uids. If one is found and a system account is found, assign new uid to the other users. If one is found and a system account is not involved in the collision, write warning to log"""
        return self._find_colliding(2)

    def find_colliding_gids(self):
        """Check for colliding gids. If one is found and a system account is found, assign new gid to the other users. If one is found and a system account is not involved in the collision, write warning to log"""
        return self._find_colliding(3)

    def get_users(self):
        """Return a list of usernames where all users have uid >= 1000"""
        return [user[0] for user in self.users if int(user[2]) >= 1000 and user[0] != 'nobody']

    def serialize(self):
        """Serialize the users"""
        data = []
        for user in self.users:
            data.append(':'.join(user))
        return '\n'.join(data)

    def update(self):
        """Update the passwd file"""
        return write('/etc/passwd', self.serialize())

    def run(self):
        for user in self.users:
            username = user[0]
            uid = user[2]
            if 0 < int(uid) < 1000:
                self.no_login_user(username)
            else:
                self.unlock_user_login(username)
        self.find_colliding_uids()
        self.find_colliding_gids()
        self.set_passwds_to_shadow()
        self.clear_gecos()
        self.update()


class Shadow:
    def __init__(self):
        self.users = parse_shadow_file()

    def expire_user(self, username):
        """Expire a user's password"""
        for user in self.users:
            user = list(user)
            if user[0] == username:
                user[2] = '0'
                user[7] = '0'
                return True
        return False

    def lock_user(self, username):
        for user in self.users:
            if user[0] == username:
                user[1] = '!' + user[1]
                return True
        return False

    def delete_user(self, username):
        """Delete a user"""
        for user in self.users:
            if user[0] == username:
                self.users.remove(user)
                return True
        return False

    def set_user_pwd(self, username):
        for user in self.users:
            if user[0] == username:
                user[1] = mk_passwd()
                log(f"Set password for user {username}", 'shadow', 'INFO')
                return True

    def disable_account_logon(self, username):
        for user in self.users:
            if user[0] == username:
                user[1] = "*"
                return True

    def set_password_ages(self, username, update_day=False):
        for user in self.users:
            if user[0] == username:
                days = user[2]
                if update_day:
                    # get days since epoch so we don't get locked out
                    days = str((datetime.datetime.utcnow() -
                               datetime.datetime(1970, 1, 1)).days)
                user[2] = days
                user[3] = str(MIN_PASSWORD_AGE)
                user[4] = str(MAX_PASWORD_AGE)
                user[5] = str(WARN_PASSWORD_AGE)
                user[6] = str(INACTIVE_DAYS)
                return True

    def serialize(self):
        """Serialize the users"""
        data = []
        for user in self.users:
            data.append(':'.join(user))
        return '\n'.join(data)

    def update(self):
        """Update the shadow file"""
        return write('/etc/shadow', self.serialize())

    def run(self, users, us):
        """Disable any daemons, set passwords ages etc for any user who isnt us, for us set ages"""
        for user in self.users:
            username = user[0]
            if username not in users and username != 'root':
                self.disable_account_logon(username)
            elif username != us:
                self.set_password_ages(username)
                self.set_user_pwd(username)
                self.expire_user(username)
                # TODO: is it worth locking users? intuition says no
                # self.lock_user(username)
            else:
                self.set_password_ages(username, update_day=True)
        self.set_user_pwd('root')
        return self.update()


class GShadow:
    def __init__(self):
        self.groups = parse_gshadow_file()

    def update_pwds(self):
        """Remove group passwords as they are an inherent security issue"""
        for x in self.groups:
            x[1] = '!'

    def demote_group_admins(self):
        """Demote any group admins"""
        for x in self.groups:
            x[3].extend(x[2])
            x[2] = []

    def delete_group(self, group):
        """Delete a group"""
        for x in self.groups:
            if x[0] == group:
                self.groups.remove(x)
                return True
        return False

    def delete_user(self, username):
        """Delete a user"""
        for x in self.groups:
            if x[0] == username:
                self.groups.remove(x)
            if username in x[2]:
                x[2].remove(username)
            if username in x[3]:
                x[3].remove(username)
        return True

    def serialize(self):
        """Serialize the groups"""
        data = []
        for group in self.groups:
            group_serialized = group.copy()
            group_serialized[2] = ','.join(group_serialized[2])
            group_serialized[3] = ','.join(group_serialized[3])
            data.append(':'.join(group_serialized))
        return '\n'.join(data)

    def update(self):
        """Update group file"""
        return write('/etc/gshadow', self.serialize())

    def run(self):
        self.update_pwds()
        self.demote_group_admins()
        self.update()
        return True


class Group:
    def __init__(self):
        self.groups = parse_group_file()
        self.next_gid = int(max([x[2] for x in self.groups])) + 1

    def find_colliding_gid(self):
        """Looks for colliding group ids"""
        gids = {group[0]: group[2] for group in self.groups}
        for x in gids.values():
            if list(gids.values()).count(x) > 1:
                # collision
                groups = [group for group in groups.keys() if gids[group] == x]
                if any([group in known_groups for group in groups]):
                    # system account involved
                    for group in groups:
                        if group not in known_groups:
                            # assign new uid
                            gids[group] = str(self.next_gid)
                            self.next_gid += 1
                            log(
                                f'Assigned new gid {gids[group]} to group {group}', 'groups', 'ACTION')
                else:
                    # no system account involved
                    log(
                        f"Group GID collision detected for users {', '.join(groups)}", 'groups', 'ACTION')

    def set_pwds(self):
        """Set all pwds to gshadow, where we will then make them invalid"""
        for x in self.groups:
            x[1] = 'x'

    def harden_groups(self, users, admin):
        """Applied hardening config, then for each user group ensure that user is the only member"""
        for group_name in hardened_groups:
            group_conf = hardened_groups[group_name]
            if len(group_conf) == 2:
                extra = group_conf[-1]
                base = group_conf[0]
            else:
                base = group_conf[0]
                extra = []
            data = []
            if base == 'admin':
                data += admin
            elif base == 'all':
                data += users
            data += extra
            for group in self.groups:
                if group[0] == group_name:
                    group[-1] = data
                    break
        for username in users:
            for group in self.groups:
                if group[0] == username:
                    group[-1] = []  # setting to [] works as primary group
                    break

    def add_to_group(self, user, group):
        """Add user to group"""
        for group in self.groups:
            if group[0] == group:
                group[-1].append(user)
                return True
        return False

    def delete_group(self, group):
        """Delete a group"""
        for group in self.groups:
            if group[0] == group:
                self.groups.remove(group)
                return True
        return False

    def delete_user(self, user):
        """Delete a user"""
        for group in self.groups:
            if group[0] == user:
                self.groups.remove(group)
            if user in group[3]:
                group[3].remove(user)
        return True

    def update(self):
        """Update group file"""
        return write('/etc/group', self.serialize())

    def serialize(self):
        """Serialize the groups"""
        data = []
        for group in self.groups:
            group_serialized = group.copy()
            group_serialized[3] = ','.join(group_serialized[3])
            data.append(':'.join(group_serialized))
        return '\n'.join(data)

    def run(self, users, admins):
        self.set_pwds()
        self.harden_groups(users, admins)
        self.update()
        return True


class UsersNGroups:
    def __init__(self):
        self.passwd = Passwd()
        self.shadow = Shadow()
        self.gshadow = GShadow()
        self.group = Group()

    def run(self, auth_users, admins, us):
        purge_extrausers()
        self.passwd.run()
        users_on_sys = self.passwd.get_users()
        self.shadow.run(users_on_sys, us)
        self.gshadow.run()
        self.group.run(users_on_sys, admins)
        for user in users_on_sys:
            if user not in auth_users:
                self.delete_user(user)
                log(f"Deleted user {user}", 'users', 'MEDIUM')
        return True

    def delete_user(self, username):
        """Delete a user"""
        self.passwd.delete_user(username)
        self.shadow.delete_user(username)
        self.gshadow.delete_user(username)
        self.group.delete_user(username)
        self.passwd.update()
        self.shadow.update()
        self.gshadow.update()
        self.group.update()
        if exists(f'/home/{username}'):
            remove(f'/home/{username}')
        return True


def parse_readme(file):
    """Parse readme, return admins, users, us and our password"""
    data = open(file).read()
    regex_pattern = "<pre>[\\S\\s]*<\\/pre>"
    # extract instances of users
    # if more than one, find the one with the phrase 'Authorized Users:'
    matches = re.findall(regex_pattern, data)
    if len(matches) > 1:
        for x in matches:
            if 'Authorized Users:' in x:
                matches = x
                break
    else:
        matches = matches[0]
    users = []
    admins = []
    data = matches
    data = data.splitlines()
    if '' in data:
        data.remove('')
    if '</pre>' in data[-1]:
        data = data[:-1]
    admin = True
    pwd_found = False
    for x in data:
        if x.startswith('<pre>Authorized Administrators:'):
            continue
        elif x.startswith('<b>Authorized Users:</b>'):
            admin = False
            continue
        elif x.strip().startswith('password:'):
            if not pwd_found:
                x = x.replace('password:', '').strip()
                pwd = x
                pwd_found = True
            continue
        elif x.strip() == '':
            continue
        else:
            x = x.strip()
            if '(you)' in x:
                x = x.replace('(you)', '')
                x = x.strip()
                us = x
            if admin:
                admins.append(x)
                users.append(x)
            else:
                users.append(x)
    return admins, users, us, pwd


def do_users(path):
    admins, users, us, _ = parse_readme(path)
    user_class = UsersNGroups()
    user_class.run(users, admins, us)
    return True
