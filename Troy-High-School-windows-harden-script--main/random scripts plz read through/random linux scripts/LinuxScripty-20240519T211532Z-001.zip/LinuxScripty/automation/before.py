# fmt: off
from os.path import abspath
from sys import path
path.append(abspath(__file__ + '../../'))
from utils import *
# fmt: on
def setup_grub():
    # pwd, _, _ = run_command_unhandled(
    #    f'echo -e {user_pwd}\n{user_pwd}" | grub-mkpasswd-pbkdf2 | tail -n 1 | rev | cut -d" " -f1 | rev')
    pwd = 'grub.pbkdf2.sha512.10000.9CBE6D11615C92213555B7297DE96A9C1A974D63E0FE49CB2C1D5D2974A282BBB4205CC0D3F42F508DECF9D0ED719BD128DE8709066C517E4F9B895E7A96163A.C2729676228BC330C47B04EE857F6E3993F059EFF9986689F205DF4B11BDA96711D670188BB067961B8FA956BB66033662936E46ABB1BD9533DEF7B7CED052BB'

    create_file('/etc/grub.d/00_hardening')
    append('/etc/grub.d/00_hardening', 'set superusers="root"', repeat=False)
    append('/etc/grub.d/00_hardening', f'password_pbkdf2 root {pwd}', repeat=False)
    append('/etc/grub.d/00_hardening', 'set check_signatures=enforce', repeat=False)
    append('/etc/grub.d/00_hardening', 'set shim_lock=y', repeat=False)
    append('/etc/grub.d/00_hardening', 'set lockdown=y', repeat=False)
    for x in listdir('/etc/grub.d/'):
        if isdir(f'/etc/grub.d/{x}'):
            continue
        setkey(f'/etc/grub.d/{x}', "set superusers=.*",
               f"set superusers=\"root\"")
        setkey(f'/etc/grub.d/{x}', "password_pbkdf2 root .*\n",
               f"password_pbkdf2 root {pwd}\n")
        setkey(f'/etc/grub.d/{x}', "set check_signatures=.*",
                f"set check_signatures=enforce")
        setkey(f'/etc/grub.d/{x}', "set shim_lock=.*",
                f"set shim_lock=y")
        setkey(f'/etc/grub.d/{x}', "set lockdown=.*",
                f"set lockdown=y")
    copyfile(f"{configs_dir}/grub", "/etc/default/grub")
    run_command_unhandled('update-grub 2>/dev/null')

def configure_fstab():
    """
    typ = run_command_unhandled("lsblk | grep disk | cut -d' ' -f1")[0].strip()
    num = int(run_command_unhandled(
        f"lsblk /dev/{typ} | tail -n 1 | cut -d' ' -f1")[0].strip().split(typ)[1])
    num += 1
    dirs = {
        "var": ["defaults", "rw", "nosuid", "nodev", "relatime"],
        "var/tmp": ["defaults", "rw", "nosuid", "nodev", "noexec", "relatime"],
        "var/log": ["defaults", "rw", "nosuid", "nodev", "noexec", "relatime"],
        "var/log/audit": ["defaults", "rw", "nosuid", "nodev", "noexec", "relatime"],
        "dev/shm": ["defaults", "rw", "nosuid", "nodev", "noexec", "relatime"],
        "home": ["defaults", "rw", "nosuid", "nodev", "relatime"],

    }
    for dir in dirs:
        configure_fstab_entry(dir, dirs[dir], f"/dev/{typ}{num}")
    """
    # tmpfs
    copyfile(f'{configs_dir}/tmp.mount', '/usr/lib/systemd/system/tmp.mount')
    run_command_unhandled('systemctl daemon-reload')
    run_command_unhandled('systemctl unmask tmp.mount')
    run_command_unhandled('systemctl start tmp.mount')
    append('/etc/fstab',
           f'tmpfs /tmp tmpfs defaults,rw,nosuid,nodev,noexec,relatime,size=5G 0 0', repeat=False)
    # remount /tmp
    run_command_unhandled('mount -o remount /tmp')
    # procfs
    append('/etc/fstab', f'proc    /proc        proc        defaults,hidepid=2    0 0', repeat=False)
    # remount /proc
    run_command_unhandled('mount -o remount /proc')
    return True


def clear_crontabs():
    """Clear all crontabs"""
    for x in listdir('/var/spool/cron/crontabs/'):
        remove(f'/var/spool/cron/crontabs/{x}')
    dirs = ['/etc/cron.d', '/etc/cron.daily',
            '/etc/cron.hourly', '/etc/cron.monthly', '/etc/cron.weekly']
    dirs = [x[1:] for x in dirs if exists(x)]
    # replace with baselined cron
    for dir in dirs:
        b_dir = join(f'{baselines_dir}/fs', dir)
        if exists(b_dir):
            copy(b_dir, '/' + dir)
    copy(f'{baselines_dir}/fs/etc/crontab', '/etc/crontab')
    return True


def clear_at():
    """"Clear all at jobs"""
    # /var/spool/cron/atjobs/
    for x in listdir('/var/spool/cron/atjobs/'):
        remove(f'/var/spool/cron/atjobs/{x}')
    return True


def clear_anacron():
    for x in listdir('/var/spool/anacron/'):
        remove(f'/var/spool/anacron/{x}')
    remove('/etc/anacrontab')
    return True


def apply_updates():
    run_command_unhandled('apt-get update -y')
    run_command_unhandled('NEEDRESTART_MODE=a apt-get dist-upgrade -y')
    run_command_unhandled('NEEDRESTART_MODE=a apt-get upgrade -y')
    copyfile(f"{configs_dir}/sources.list", "/etc/apt/sources.list")
    run_command_unhandled('apt-get update -y')
    run_command("apt-mark unhold $(apt-mark showhold)")
    log("Unheld packages (may need to check now if things can be updated)", 'auto-before')
    packages = ['libpam-pwquality', 'ufw', 'auditd', 'rsyslog',
                'apparmor-utils', 'apparmor-profiles']
    try:
        run_command_unhandled(
            '(echo unattended-upgrades unattended-upgrades/enable_auto_updates boolean true | debconf-set-selections) && dpkg-reconfigure -f noninteractive unattended-upgrades')
    except:
        pass
    install(packages)
    log('Installed packages', 'auto-before')
    to_uninstall = ['cups*', 'bluetooth*', 'apport*', 'popularity-contest*',
                    'tracker*', 'tracker-extract', 'tracker-miner-fs*', 'nis*', 'rsh-client*', 'talk*', 'telnet', 'avahi-daemon*', 'thunderbird*']
    for package in to_uninstall:
        uninstall(package)
    log('Uninstalled packages', 'auto-before')
    #run_command_unhandled('apt-get update -y')
    run_command_unhandled('NEEDRESTART_MODE=a apt-get upgrade -y')
    log('Upgraded packages', 'auto-before')
    run_command_unhandled('NEEDRESTART_MODE=a apt-get dist-upgrade -y')
    log('D-Upgraded packages', 'auto-before')
    run_command_unhandled('apt-get autoremove -y')
    run_command_unhandled('apt-get autoclean -y')
    log('Uninstalled excess packages', 'auto-before')


def automation_before():
    run_command_unhandled(f'chown root:root {configs_dir}/*')
    run_command_unhandled(f'chmod 644 {configs_dir}/*')

    # TODO: clear systemd timers
    apply_updates()
    clear_anacron()
    clear_crontabs()
    clear_at()
    configure_fstab()
    if exists('/etc/gdm3'):
        copyfile(f"{configs_dir}/gdm3.conf", "/etc/gdm3/custom.conf")
        copyfile(f"{configs_dir}/dconf-user", "/etc/dconf/profile/user")
        create_dir("/etc/dconf/db/gdm.d")
        copyfile(f"{configs_dir}/greeter.dconf-defaults",
                 "/etc/dconf/db/gdm.d/00-greeter")
        copyfile(f"{configs_dir}/greeter.dconf-defaults",
                 "/etc/gdm3/greeter.dconf-defaults")
        if not exists("/etc/dconf/db/gdm.d/locks"):
            create_dir("/etc/dconf/db/gdm.d/locks")
        copyfile(f"{configs_dir}/gdm-lockfile",
                 "/etc/dconf/db/gdm.d/locks/00-greeter")
        log("Configured GDM", 'auto-before')
    create_dir('/etc/dconf/db/local.d')
    copyfile(f"{configs_dir}/disable-CAD",
             "/etc/dconf/db/local.d/00-disable-CAD")
    create_dir('/etc/dconf/db/local.d/locks')
    copyfile(f"{configs_dir}/disable-CAD-lock",
             "/etc/dconf/db/local.d/locks/00-disable-CAD")
    run_command_unhandled('dconf update')
    log("Configured dconf", 'auto-before')
    write("/etc/donothackpls", "Don't hack pls")
    copyfile(f"{configs_dir}/pwquality.conf", "/etc/security/pwquality.conf")
    copyfile(f"{configs_dir}/access.conf", "/etc/security/access.conf")
    copyfile(f"{configs_dir}/login.defs", "/etc/login.defs")
    log("Configured login, pwquality, and access", 'auto-before')

    #setkey('/etc/default/ufw', "IPV6=.*", "IPV6=no")
    #setkey('/etc/default/ufw', "IPT_SYSCTL=.*", "IPT_SYSCTL=/etc/sysctl.conf")
    run_command_unhandled('ufw enable')
    run_command_unhandled('ufw logging on')
    run_command_unhandled('ufw logging high')
    run_command_unhandled('ufw allow in on lo')
    run_command_unhandled('ufw allow out on lo')
    run_command_unhandled('ufw deny in from 127.0.0.0/8')
    run_command('ufw deny in from ::1')
    # TODO: deny outgoing as much as possible
    run_command_unhandled('ufw default allow outgoing')
    run_command_unhandled('ufw default deny incoming')
    run_command_unhandled('ufw default allow routed')
    log("Configured UFW", 'auto-before')

    copyfile(f"{configs_dir}/sysctl.conf", "/etc/sysctl.conf")

    run_command_unhandled('sysctl -p 2>/dev/null')
    log("Configured sysctl", 'auto-before')
    for x in listdir(f"{configs_dir}/pam"):
        copyfile(f"{configs_dir}/pam/{x}", f"/etc/pam.d/{x}")
    log("Configured PAM", 'auto-before')
    setup_grub()
    log("Configured GRUB", 'auto-before')
    for x in listdir(f"{configs_dir}/systemd"):
        copyfile(f"{configs_dir}/systemd/{x}", f"/etc/systemd/{x}")
    log("Configured systemd", 'auto-before')
    # sticky bit on all world writable dirs
    run_command_unhandled('find / -perm -o+w -exec chmod +t {} + 2>/dev/null')
    log("Configured sticky bit", 'auto-before')
    # disable plugins of auditd
    for x in listdir('/etc/audit/plugins.d/'):
        setkey(f'/etc/audit/plugins.d/{x}', "active=.*", "active = no")

    copyfile(f"{configs_dir}/auditd.conf", "/etc/audit/auditd.conf")
    copyfile(f"{configs_dir}/audit.rules", "/etc/audit/rules.d/audit.rules")
    restart_service('auditd')
    log("Configured auditd", 'auto-before')
    start_service('apparmor')
    log("Started apparmor", 'auto-before')
    copyfile(f'{configs_dir}/limits.conf', '/etc/security/limits.conf')
    log("Configured limits", 'auto-before') 
    run_command_unhandled(
        'for x in "dccp sctp tipc rds"; do modprobe -n -v $x; echo "install $x /bin/true" >> /etc/modprobe.d/ubuntu.conf; done')
    log("Disabled dccp, sctp, tipc, and rds", 'auto-before')
    copyfile(f"{configs_dir}/50unattended-upgrades",
             "/etc/apt/apt.conf.d/00hardening")
    log("Configured unattended-upgrades", 'auto-before')
    copyfile(f"{configs_dir}/bash.bashrc", "/etc/bash.bashrc")
    copyfile(f"{configs_dir}/bash.bashrc", "/root/.bashrc")
    copyfile(f"{configs_dir}/bash.bashrc", "/etc/skel/.bashrc")
    copyfile(f"{configs_dir}/profile", "/etc/profile")
    copyfile(f"{configs_dir}/profile", "/root/.profile")
    copyfile(f"{configs_dir}/profile", "/etc/skel/.profile")
    for x in listdir('/home'):
        if isdir(f'/home/{x}'):
            copyfile(f"{configs_dir}/bash.bashrc", f"/home/{x}/.bashrc")
            copyfile(f"{configs_dir}/profile", f"/home/{x}/.profile")
    log("Configured bash rc files", 'auto-before')
    write('/etc/securetty', '')

    copyfile(f"{configs_dir}/faillock.conf", "/etc/security/faillock.conf")
    log("Configured faillock", "auto-before")
    copyfile(f"{configs_dir}/useradd", "/etc/default/useradd")
    log("Configured useradd", "auto-before")
    kill_service('ctrl-alt-del')
    if not exists('/etc/init'):
        create_dir('/etc/init')
    create_file('/etc/init/control-alt-delete.override')
    create_file('/etc/init/control-alt-delete.conf')
    log("Stabbed ctrl alt del even more!", "auto-before")

    write("/etc/sudo.conf", "")

    copyfile(f"{configs_dir}/sudoers", "/etc/sudoers")
    log("Configured Sudoers", "auto-before")
    copyfile(f"{configs_dir}/shells", "/etc/shells")
    remove('/etc/nologin')

    copyfile(f"{configs_dir}/environment", "/etc/environment")

    copyfile(f"{configs_dir}/kerneloops.conf", "/etc/kerneloops.conf")

    write("/etc/subuid", "")
    write("/etc/subgid", "")

    copyfile(f"{configs_dir}/overlayroot.conf", "/etc/overlayroot.conf")

    write("/etc/pam.conf", "")

    copyfile(f"{configs_dir}/dpkg.cfg", "/etc/dpkg/dpkg.cfg")

    copyfile(f"{configs_dir}/origins", "/etc/dpkg/origins/default")

    run_command_unhandled('apt-mark unhold $(apt-mark showhold) 2>/dev/null')

    write("/etc/apt/auth.conf", "")

    copyfile(f"{configs_dir}/logrotate.conf", "/etc/logrotate.conf")

    copyfile(f"{configs_dir}/adduser.conf", "/etc/adduser.conf")
    copyfile(f"{configs_dir}/deluser.conf", "/etc/deluser.conf")
    if exists('/etc/default/apport'):
        setkey('/etc/default/apport', 'enabled=.*', 'enabled=0')
    if exists('/etc/default/whoopsie'):
        setkey('/etc/default/whoopsie',
               'report_crashes=.*', 'report_crashes=false')
        setkey('/etc/default/whoopsie', 'enabled=.*', 'enabled=0')
    if exists('/etc/default/irqbalance'):
        setkey('/etc/default/irqbalance', 'ENABLED=.*', 'ENABLED="0"')
    write("/etc/default/login", "CONSOLE=/dev/login")
    kill_service('whoopsie')
    kill_service('irqbalance')
    kill_service('apport')
    kill_service('popularity-contest')
    kill_service('tracker*')
    kill_service('rsync')
    kill_service('kdump')
    log("Killed services", 'auto-before')
    run_command_unhandled('systemctl daemon-reload')
