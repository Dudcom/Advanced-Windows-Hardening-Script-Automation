# fmt: off
from os.path import abspath
from sys import path
path.append(abspath(__file__ + '../../'))
from utils import *
# fmt: on


def automation_after():
    #apply_attrs()
    apply_perms()

def set_base_attrs():
    """Apply file attributes"""
    # these files are all attrs that are not only e
    base_attrs = open(f"{baselines_dir}/attrs").read().splitlines()
    if '' in base_attrs:
        base_attrs.remove('')
    attrs = base_attrs
    files = []
    for attr in attrs:
        attr, file = attr.split(' ')
        file = process_path(file)
        files.append(file)
        attr = attr.replace('-', '')
        new_attr = ""
        for x in attr:
            if x in 'aAcCdDeijPsStTuFx':
                new_attr += x
        if new_attr == "":
            new_attr = "e"
        if not exists(file):
            continue
        try:
            chattr(file, new_attr)
        except:
            log(f"Failed to apply {new_attr} to {file}",
                'auto-after', priority='WARN')
    other_attrs = run_command_unhandled(
        "lsattr -R / 2>/dev/null | grep -v : | grep '\S' | grep -v '\-\-\-\-\-\-\-\-\-\-\-\-\-\-e\-\-\-\-\-\-\-' | grep -v '/sys' | grep -v '/proc'")[0].strip().splitlines()
    if '' in other_attrs:
        other_attrs.remove('')
    for attr in other_attrs:
        attr, file = attr.split(' ')
        file = process_path(file)
        if file not in files:
            try:
                # get that da fuck back to being default
                chattr(file, '=e')
            except:
                log(f"Failed to reset attributes on {file}",
                    'auto-after', priority='WARN')
    return True

@requires(files=['/baselines/attrs.out'])
def apply_attrs():
    """Apply file attributes"""
    # these files are all attrs that are not only e
    if not exists('/baselines/attrs.out'):
        return False
    base_attrs = open(f"{baselines_dir}/attrs").read().splitlines()
    if '' in base_attrs:
        base_attrs.remove('')
    dynamic_attrs = open(
        '/baselines/attrs.out').read().splitlines()
    if '' in dynamic_attrs:
        dynamic_attrs.remove('')
    attrs = dynamic_attrs + base_attrs
    files = []
    for attr in attrs:
        attr, file = attr.split(' ')
        file = process_path(file)
        files.append(file)
        attr = attr.replace('-', '')
        new_attr = ""
        for x in attr:
            if x in 'aAcCdDeijPsStTuFx':
                new_attr += x
        if new_attr == "":
            new_attr = "e"
        if not exists(file):
            continue
        try:
            chattr(file, new_attr)
        except:
            log(f"Failed to apply {new_attr} to {file}",
                'auto-after', priority='WARN')
    other_attrs = run_command_unhandled(
        "lsattr -R / 2>/dev/null | grep -v : | grep '\S' | grep -v '\-\-\-\-\-\-\-\-\-\-\-\-\-\-e\-\-\-\-\-\-\-' | grep -v '/sys' | grep -v '/proc'")[0].strip().splitlines()
    if '' in other_attrs:
        other_attrs.remove('')
    for attr in other_attrs:
        attr, file = attr.split(' ')
        file = process_path(file)
        if file not in files:
            try:
                # get that da fuck back to being default
                chattr(file, '=e')
            except:
                log(f"Failed to reset attributes on {file}",
                    'auto-after', priority='WARN')
    return True

@requires(files=['/baselines/acls.out'])
def apply_perms():
    """Apply file permissions"""
    # apply them seperately is easier, via setfacl --restore
    setfacls(open('/baselines/acls.out').read().strip() + "\n\n" + open(f'{baselines_dir}/acls').read().strip() + "\n\n")
    log("Applied base permissions", "acls")
    return True
