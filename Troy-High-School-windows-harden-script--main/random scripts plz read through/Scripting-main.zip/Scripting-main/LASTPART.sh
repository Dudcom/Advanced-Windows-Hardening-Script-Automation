echo "

Kernel Modules --> kisnit module load/unload

var/www

ssh keys for different users

search for #!/usr/bin/env/python3 slash SHEBANGS for scripts in BINs

check bins in python
alias

grub.d ;

lsattr /etc and other things?

"

